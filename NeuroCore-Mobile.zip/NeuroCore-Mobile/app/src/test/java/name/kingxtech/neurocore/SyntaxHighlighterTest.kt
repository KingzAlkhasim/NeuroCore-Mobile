package name.kingxtech.neurocore

import name.kingxtech.neurocore.markdown.SyntaxHighlighter
import name.kingxtech.neurocore.markdown.TokenType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SyntaxHighlighterTest {
    private fun types(code: String, lang: String?) =
        SyntaxHighlighter.highlight(code, lang).map { code.substring(it.start, it.end) to it.type }

    @Test fun kotlinBasics() {
        val t = types("fun greet(name: String) = \"hi\" // done", "kotlin")
        assertTrue("fun" to TokenType.Keyword in t)
        assertTrue("greet" to TokenType.Function in t)
        assertTrue("String" to TokenType.Type in t)
        assertTrue("\"hi\"" to TokenType.String in t)
        assertTrue("// done" to TokenType.Comment in t)
    }

    @Test fun pythonCommentsAndTripleQuotes() {
        val t = types("# hello\ndef f():\n    \"\"\"doc\"\"\"\n    return 42", "py")
        assertTrue("# hello" to TokenType.Comment in t)
        assertTrue("def" to TokenType.Keyword in t)
        assertTrue("\"\"\"doc\"\"\"" to TokenType.String in t)
        assertTrue("42" to TokenType.Number in t)
    }

    @Test fun jsonKeysAreAttributes() {
        val t = types("{\"a\": 1, \"b\": \"x\"}", "json")
        assertTrue("\"a\"" to TokenType.Attribute in t)
        assertTrue("\"x\"" to TokenType.String in t)
        assertTrue("1" to TokenType.Number in t)
    }

    @Test fun htmlTagsAndAttributes() {
        val t = types("<div class=\"a\">x</div>", "html")
        assertTrue("<div" to TokenType.Tag in t)
        assertTrue("class" to TokenType.Attribute in t)
        assertTrue("\"a\"" to TokenType.String in t)
    }

    @Test fun bashVariables() {
        val t = types("echo \$HOME # note", "bash")
        assertTrue("echo" to TokenType.Keyword in t)
        assertTrue("\$HOME" to TokenType.Annotation in t)
    }

    @Test fun cPreprocessor() {
        val t = types("#include <stdio.h>\nint main() { return 0; }", "cpp")
        assertTrue("#include <stdio.h>" to TokenType.Annotation in t)
        assertTrue("int" to TokenType.Keyword in t)
        assertTrue("main" to TokenType.Function in t)
    }

    @Test fun tokensAreOrderedAndInBounds() {
        val code = "val s = \"unterminated\nval n = 0xFF + 1.5e3\n/* open"
        var last = 0
        for (tok in SyntaxHighlighter.highlight(code, "kotlin")) {
            assertTrue(tok.start >= last)
            assertTrue(tok.end <= code.length && tok.end > tok.start)
            last = tok.end
        }
    }

    @Test fun unknownLanguageStillSafe() {
        assertEquals(emptyList<Any>(), SyntaxHighlighter.highlight("", "kotlin"))
        SyntaxHighlighter.highlight("some text 'x' 12", "klingon")
        SyntaxHighlighter.highlight("some text", null)
    }
}
