package name.kingxtech.neurocore

import name.kingxtech.neurocore.engine.DownloadMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DownloadMathTest {
    @Test fun contentRangeTotal() {
        assertEquals(1000L, DownloadMath.parseContentRangeTotal("bytes 100-999/1000"))
        assertEquals(null, DownloadMath.parseContentRangeTotal("bytes 100-999/*"))
        assertEquals(null, DownloadMath.parseContentRangeTotal(null))
        assertEquals(null, DownloadMath.parseContentRangeTotal("garbage"))
    }

    @Test fun formatting() {
        assertEquals("1.12 GB", DownloadMath.formatBytes(1_120_000_000L))
        assertEquals("412 MB", DownloadMath.formatBytes(412_500_000L))
        assertEquals("5 KB", DownloadMath.formatBytes(5_000L))
    }

    @Test fun ggufMagic() {
        assertTrue(DownloadMath.looksLikeGguf("GGUF\u0003\u0000".toByteArray(Charsets.ISO_8859_1)))
        assertFalse(DownloadMath.looksLikeGguf("<html>".toByteArray()))
        assertFalse(DownloadMath.looksLikeGguf(ByteArray(2)))
    }

    @Test fun fractionIsClamped() {
        assertEquals(0f, DownloadMath.fraction(5, 0))
        assertEquals(1f, DownloadMath.fraction(20, 10))
        assertEquals(0.5f, DownloadMath.fraction(5, 10))
    }
}
