package name.kingxtech.neurocore

import name.kingxtech.neurocore.engine.PromptBuilder
import name.kingxtech.neurocore.engine.Utf8StreamDecoder
import name.kingxtech.neurocore.tts.SpeechText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EngineHelpersTest {

    @Test fun utf8SplitAcrossTokens() {
        val bytes = "héllo 😀!".toByteArray(Charsets.UTF_8)
        val d = Utf8StreamDecoder()
        val sb = StringBuilder()
        for (b in bytes) sb.append(d.push(byteArrayOf(b)))
        sb.append(d.finish())
        assertEquals("héllo 😀!", sb.toString())
    }

    @Test fun utf8DanglingByteIsReplacedNotThrown() {
        val d = Utf8StreamDecoder()
        assertEquals("", d.push(byteArrayOf(0xF0.toByte(), 0x9F.toByte())))
        assertEquals("\uFFFD", d.finish())
    }

    @Test fun promptUsesChatMl() {
        val p = PromptBuilder.build(listOf(PromptBuilder.Turn("user", "Hi")), "SYS")
        assertEquals("<|im_start|>system\nSYS<|im_end|>\n<|im_start|>user\nHi<|im_end|>\n<|im_start|>assistant\n", p)
    }

    private val count: (String) -> Int = { it.length / 4 + 1 }

    @Test fun trimDropsOldestAndStartsWithUser() {
        val turns = (1..20).flatMap {
            listOf(PromptBuilder.Turn("user", "q$it " + "x".repeat(200)), PromptBuilder.Turn("assistant", "a$it " + "y".repeat(200)))
        }
        val kept = PromptBuilder.trim(turns, 600, "sys", count)
        assertTrue(kept.size < turns.size)
        assertEquals("user", kept.first().role)
        assertEquals(turns.last(), kept.last())
    }

    @Test fun trimKeepsEverythingWhenItFits() {
        val turns = listOf(PromptBuilder.Turn("user", "hi"), PromptBuilder.Turn("assistant", "hello"), PromptBuilder.Turn("user", "ok"))
        assertEquals(turns, PromptBuilder.trim(turns, 1000, "sys", count))
    }

    @Test fun trimShortensSingleHugeMessage() {
        val huge = PromptBuilder.Turn("user", "z".repeat(40_000))
        val kept = PromptBuilder.trim(listOf(huge), 500, "sys", count)
        assertEquals(1, kept.size)
        assertTrue(kept[0].text.length < huge.text.length)
        assertTrue(count(kept[0].text) < 500)
    }

    @Test fun speechSkipsCodeAndEmoji() {
        val s = SpeechText.toSpeakable("# Hello 😀\n\nUse **this**:\n\n```kotlin\nval x = 1\n```\n\n- one\n- two")
        assertTrue(s.contains("Hello."))
        assertTrue(s.contains("Use this"))
        assertTrue(s.contains("Code snippet omitted."))
        assertTrue(!s.contains("val x"))
        assertTrue(!s.contains("😀"))
        assertTrue(s.contains("one") && s.contains("two"))
    }

    @Test fun chunkingRespectsLimitAndKeepsText() {
        val text = (1..60).joinToString(" ") { "This is sentence number $it." }
        val chunks = SpeechText.chunk(text, 200)
        assertTrue(chunks.all { it.length <= 200 })
        assertEquals(text, chunks.joinToString(" "))
        val longWord = SpeechText.chunk("a".repeat(1000), 100)
        assertTrue(longWord.all { it.length <= 100 })
    }
}
