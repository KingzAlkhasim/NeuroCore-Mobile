package name.kingxtech.neurocore

import name.kingxtech.neurocore.markdown.Block
import name.kingxtech.neurocore.markdown.ColumnAlign
import name.kingxtech.neurocore.markdown.Inline
import name.kingxtech.neurocore.markdown.InlineParser
import name.kingxtech.neurocore.markdown.MarkdownParser
import name.kingxtech.neurocore.markdown.plainText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MarkdownParserTest {

    @Test fun headingsAndParagraphs() {
        val b = MarkdownParser.parse("# Title\n\nHello **world**")
        assertEquals(2, b.size)
        assertEquals(1, (b[0] as Block.Heading).level)
        val p = b[1] as Block.Paragraph
        assertTrue(p.inlines.any { it is Inline.Bold })
    }

    @Test fun csharpHeadingKeepsHash() {
        val h = MarkdownParser.parse("## Learn C#")[0] as Block.Heading
        assertEquals("Learn C#", h.inlines.plainText())
    }

    @Test fun fencedCodeWithLanguage() {
        val c = MarkdownParser.parse("```kotlin\nval x = 1\nprintln(x)\n```")[0] as Block.CodeBlock
        assertEquals("kotlin", c.language)
        assertEquals("val x = 1\nprintln(x)", c.code)
        assertTrue(c.closed)
    }

    @Test fun unterminatedFenceStillRendersAsCode() {
        val c = MarkdownParser.parse("Intro\n\n```python\nprint('hi')")[1] as Block.CodeBlock
        assertFalse(c.closed)
        assertEquals("print('hi')", c.code)
    }

    @Test fun inlineTripleBackticksAreNotAFence() {
        val b = MarkdownParser.parse("Use ```code``` inline")
        assertTrue(b[0] is Block.Paragraph)
    }

    @Test fun bulletListWithoutBlankLineAfterIntro() {
        val b = MarkdownParser.parse("Steps:\n- one\n- two\n- three")
        assertEquals(2, b.size)
        val list = b[1] as Block.ListBlock
        assertFalse(list.ordered)
        assertEquals(3, list.items.size)
    }

    @Test fun looseNumberedListWithCodeInsideItems() {
        val md = "1. First\n\n   ```bash\n   ls -la\n   ```\n\n2. Second\n3. Third"
        val list = MarkdownParser.parse(md)[0] as Block.ListBlock
        assertTrue(list.ordered)
        assertEquals(3, list.items.size)
        assertTrue(list.items[0].any { it is Block.CodeBlock })
    }

    @Test fun nestedList() {
        val list = MarkdownParser.parse("- a\n  - b\n  - c\n- d")[0] as Block.ListBlock
        assertEquals(2, list.items.size)
        assertTrue(list.items[0].any { it is Block.ListBlock })
    }

    @Test fun nestedBulletsUnderNumberedItemWithTwoSpaces() {
        val list = MarkdownParser.parse("1. Item\n  - sub\n2. Next")[0] as Block.ListBlock
        assertEquals(2, list.items.size)
        assertTrue(list.items[0].any { it is Block.ListBlock })
    }

    @Test fun orderedListStartNumber() {
        val list = MarkdownParser.parse("3. a\n4. b")[0] as Block.ListBlock
        assertEquals(3, list.start)
    }

    @Test fun table() {
        val t = MarkdownParser.parse("| Name | Score |\n|:--|--:|\n| A | 1 |\n| B | 2 |")[0] as Block.Table
        assertEquals(2, t.header.size)
        assertEquals(listOf(ColumnAlign.START, ColumnAlign.END), t.aligns)
        assertEquals(2, t.rows.size)
        assertEquals("B", t.rows[1][0].plainText())
    }

    @Test fun horizontalRuleIsNotATable() {
        val b = MarkdownParser.parse("a | b\n---")
        assertTrue(b.none { it is Block.Table })
        assertTrue(b.any { it is Block.Rule })
    }

    @Test fun blockQuote() {
        val q = MarkdownParser.parse("> quoted **text**\n> more")[0] as Block.Quote
        assertEquals(1, q.blocks.size)
    }

    @Test fun boldItalicStrikeCode() {
        val i = InlineParser.parse("**b** *i* ~~s~~ `c`")
        assertTrue(i.any { it is Inline.Bold })
        assertTrue(i.any { it is Inline.Italic })
        assertTrue(i.any { it is Inline.Strike })
        assertTrue(i.any { it is Inline.Code })
    }

    @Test fun tripleStarIsBoldItalic() {
        val i = InlineParser.parse("***both***")
        val bold = i.single() as Inline.Bold
        assertTrue(bold.children.single() is Inline.Italic)
    }

    @Test fun snakeCaseStaysLiteral() {
        assertEquals("my_var_name", InlineParser.parse("my_var_name").plainText())
        assertTrue(InlineParser.parse("my_var_name").all { it is Inline.Text })
    }

    @Test fun mathStarsStayLiteral() {
        assertEquals("2 * 3 * 4", InlineParser.parse("2 * 3 * 4").plainText())
    }

    @Test fun unclosedMarkersStayLiteralWhileStreaming() {
        assertEquals("**partial bold", InlineParser.parse("**partial bold").plainText())
    }

    @Test fun links() {
        val l = InlineParser.parse("see [docs](https://a.dev/x_(y)) now").filterIsInstance<Inline.Link>().single()
        assertEquals("https://a.dev/x_(y)", l.url)
        assertEquals("docs", l.children.plainText())
    }

    @Test fun bareUrlTrimsTrailingPunctuation() {
        val l = InlineParser.parse("Visit https://example.com/a.").filterIsInstance<Inline.Link>().single()
        assertEquals("https://example.com/a", l.url)
    }

    @Test fun escapesAndBreaks() {
        assertEquals("*not italic*", InlineParser.parse("\\*not italic\\*").plainText())
        assertEquals("a\nb", InlineParser.parse("a<br>b").plainText())
    }

    @Test fun codeSpanProtectsMarkers() {
        val c = InlineParser.parse("`a**b**c`").single() as Inline.Code
        assertEquals("a**b**c", c.code)
    }

    @Test fun neverThrowsOnGarbage() {
        val nasty = listOf("[", "[]()", "![", "```", "~~", "**", "|", "|-|", "> ", "- ", "1.", "<", "`", "\\", "*_*_*", "[a](b", "# ", "<br")
        for (s in nasty) {
            MarkdownParser.parse(s)
            MarkdownParser.parse("x\n$s\ny")
        }
    }
}
