package name.kingxtech.neurocore

import name.kingxtech.neurocore.engine.DeviceProfile
import name.kingxtech.neurocore.engine.Fit
import name.kingxtech.neurocore.engine.ModelCatalog
import name.kingxtech.neurocore.engine.ModelRecommender
import name.kingxtech.neurocore.engine.PromptBuilder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelRecommenderTest {
    // Tecno Camon 12: 8x Cortex-A53, about 4 GB RAM, no dot-product instructions.
    private val camon12 = DeviceProfile(3_700_000_000L, is64BitArm = true, hasDotProduct = false, cores = 8)
    private val flagship = DeviceProfile(7_600_000_000L, is64BitArm = true, hasDotProduct = true, cores = 8)
    private val midRange = DeviceProfile(3_800_000_000L, is64BitArm = true, hasDotProduct = true, cores = 8)
    private val lowRam = DeviceProfile(1_900_000_000L, is64BitArm = true, hasDotProduct = false, cores = 4)
    private val x86 = DeviceProfile(8_000_000_000L, is64BitArm = false, hasDotProduct = false, cores = 8)

    @Test fun camon12GetsLiteRecommendedAndStandardSlow() {
        assertEquals(ModelCatalog.lite.id, ModelRecommender.recommended(camon12)?.id)
        assertEquals(Fit.RECOMMENDED, ModelRecommender.assess(ModelCatalog.lite, camon12).fit)
        assertEquals(Fit.SLOW, ModelRecommender.assess(ModelCatalog.standard, camon12).fit)
    }

    @Test fun flagshipGetsStandard() {
        assertEquals(ModelCatalog.standard.id, ModelRecommender.recommended(flagship)?.id)
        assertEquals(Fit.OK, ModelRecommender.assess(ModelCatalog.lite, flagship).fit)
    }

    @Test fun midRangeWithDotProductGetsStandard() {
        assertEquals(ModelCatalog.standard.id, ModelRecommender.recommended(midRange)?.id)
    }

    @Test fun lowMemoryOnlyAllowsLite() {
        assertEquals(Fit.UNAVAILABLE, ModelRecommender.assess(ModelCatalog.standard, lowRam).fit)
        assertEquals(ModelCatalog.lite.id, ModelRecommender.recommended(lowRam)?.id)
    }

    @Test fun unsupportedProcessorBlocksEverything() {
        assertTrue(ModelCatalog.all.all { ModelRecommender.assess(it, x86).fit == Fit.UNAVAILABLE })
        assertEquals(null, ModelRecommender.recommended(x86))
    }

    @Test fun catalogLookup() {
        assertEquals(ModelCatalog.lite, ModelCatalog.byId(ModelCatalog.lite.id))
        assertEquals(null, ModelCatalog.byId("nope"))
        assertEquals(null, ModelCatalog.byId(null))
        assertTrue(ModelCatalog.lite.minValidBytes < ModelCatalog.lite.approxBytes)
    }

    @Test fun customInstructionsJoinTheSystemPrompt() {
        assertEquals(PromptBuilder.SYSTEM_PROMPT, PromptBuilder.systemPrompt("   "))
        val p = PromptBuilder.systemPrompt("Answer in French.")
        assertTrue(p.startsWith(PromptBuilder.SYSTEM_PROMPT))
        assertTrue(p.endsWith("Answer in French."))
        assertEquals(true, PromptBuilder.systemPrompt("x".repeat(5000)).length < PromptBuilder.SYSTEM_PROMPT.length + 900)
    }
}
