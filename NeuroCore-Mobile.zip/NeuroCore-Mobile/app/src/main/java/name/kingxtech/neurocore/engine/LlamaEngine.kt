package name.kingxtech.neurocore.engine

import android.os.Build

/** Called once per generated token with its raw UTF-8 bytes. Return false to stop generating. */
fun interface TokenListener {
    fun onToken(bytes: ByteArray): Boolean
}

/** Raw JNI surface. Implemented in app/src/main/cpp/neurocore_jni.cpp. */
object LlamaNative {
    @Volatile
    var libraryError: String? = null
        private set

    val isLibraryLoaded: Boolean

    init {
        var loaded = false
        try {
            System.loadLibrary("neurocore")
            loaded = true
        } catch (e: UnsatisfiedLinkError) {
            val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
            libraryError = "This device (CPU: $abi) is not supported yet. NeuroCore needs a 64-bit ARM phone."
        }
        isLibraryLoaded = loaded
    }

    external fun load(path: String, contextSize: Int, threads: Int): Long
    external fun lastError(): String
    external fun tokenCount(handle: Long, text: ByteArray): Int
    external fun generate(
        handle: Long,
        prompt: ByteArray,
        maxNewTokens: Int,
        temperature: Float,
        topP: Float,
        topK: Int,
        repeatPenalty: Float,
        seed: Int,
        listener: TokenListener,
    ): Int
    external fun cancel()
    external fun resetCache(handle: Long)
    external fun release(handle: Long)
}

data class Sampling(
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val topK: Int = 40,
    val repeatPenalty: Float = 1.08f,
)

/**
 * Thin, safe wrapper around the native engine. Every call that touches the model must come from the
 * same background thread (the ViewModel uses a dedicated single-thread dispatcher); only [cancel]
 * may be called from anywhere.
 */
class LlamaEngine {
    @Volatile
    private var handle: Long = 0L

    val isLoaded: Boolean get() = handle != 0L

    fun load(path: String, contextSize: Int, threads: Int) {
        check(LlamaNative.isLibraryLoaded) { LlamaNative.libraryError ?: "The AI engine could not be loaded." }
        if (!CpuFeatures.supportsDotProduct()) {
            throw IllegalStateException("This phone's processor is too old to run the on-device model (it needs ARMv8.2 dot-product support).")
        }
        release()
        val h = LlamaNative.load(path, contextSize, threads)
        if (h == 0L) {
            throw IllegalStateException(LlamaNative.lastError().ifBlank { "The model could not be loaded." })
        }
        handle = h
    }

    fun countTokens(text: String): Int {
        val h = handle
        if (h == 0L) return text.length / 3 + 1
        val n = LlamaNative.tokenCount(h, text.toByteArray(Charsets.UTF_8))
        return if (n >= 0) n else text.length / 3 + 1
    }

    /** Blocks until generation finishes. Returns the number of tokens produced. */
    fun generate(prompt: String, maxNewTokens: Int, sampling: Sampling = Sampling(), listener: TokenListener): Int {
        val h = handle
        check(h != 0L) { "The model is not loaded." }
        val produced = LlamaNative.generate(
            h, prompt.toByteArray(Charsets.UTF_8), maxNewTokens,
            sampling.temperature, sampling.topP, sampling.topK, sampling.repeatPenalty, -1, listener,
        )
        if (produced < 0) {
            throw IllegalStateException(LlamaNative.lastError().ifBlank { "Generation failed." })
        }
        return produced
    }

    fun cancel() {
        if (handle != 0L && LlamaNative.isLibraryLoaded) LlamaNative.cancel()
    }

    fun release() {
        val h = handle
        handle = 0L
        if (h != 0L && LlamaNative.isLibraryLoaded) LlamaNative.release(h)
    }
}

/** Detects the ARM instructions the native build requires, so we can explain instead of crashing. */
object CpuFeatures {
    fun supportsDotProduct(): Boolean {
        val is64Bit = Build.SUPPORTED_64_BIT_ABIS.isNotEmpty()
        if (!is64Bit) return false
        return try {
            val info = java.io.File("/proc/cpuinfo").readText()
            // If the file has no feature list at all, don't block the user.
            !info.contains("Features") || info.contains("asimddp")
        } catch (e: Exception) {
            true
        }
    }
}
