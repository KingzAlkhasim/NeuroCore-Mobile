package name.kingxtech.neurocore.markdown

/**
 * Block level Markdown parser. Handles what chat models actually produce: headings, fenced code
 * (including inside list items), nested lists, block quotes, GFM tables and horizontal rules.
 * An unterminated code fence is rendered as a code block so streaming looks right.
 */
object MarkdownParser {
    private const val MAX_DEPTH = 8

    private val HEADING = Regex("^\\s{0,3}(#{1,6})\\s+(.*)$")
    private val HEADING_TRAILING = Regex("\\s+#+\\s*$")
    private val RULE = Regex("^\\s{0,3}([-*_])(?:\\s*\\1){2,}\\s*$")
    private val LIST_ITEM = Regex("^(\\s*)([-*+]|\\d{1,9}[.)])(\\s+)(.*)$")
    private val TABLE_SEPARATOR = Regex("^\\s*\\|?\\s*:?-+:?\\s*(\\|\\s*:?-+:?\\s*)*\\|?\\s*$")

    fun parse(markdown: String): List<Block> {
        val lines = markdown.replace("\r\n", "\n").replace('\r', '\n').split('\n').map(::expandLeadingTabs)
        return parseLines(lines, 0)
    }

    private fun expandLeadingTabs(line: String): String {
        if (!line.startsWith("\t")) return line
        val sb = StringBuilder()
        var i = 0
        while (i < line.length && line[i] == '\t') { sb.append("    "); i++ }
        return sb.append(line, i, line.length).toString()
    }

    private fun leadingSpaces(s: String): Int {
        var i = 0
        while (i < s.length && s[i] == ' ') i++
        return i
    }

    private class Fence(val char: Char, val length: Int, val indent: Int, val language: String?)

    private fun fenceOpen(line: String): Fence? {
        val t = line.trimStart()
        if (t.length < 3) return null
        val ch = t[0]
        if (ch != '`' && ch != '~') return null
        var run = 0
        while (run < t.length && t[run] == ch) run++
        if (run < 3) return null
        val info = t.substring(run).trim()
        if (ch == '`' && info.contains('`')) return null
        val lang = info.split(Regex("\\s+")).firstOrNull { it.isNotEmpty() }
            ?.trim('{', '}', '.')?.lowercase()?.takeIf { it.isNotEmpty() }
        return Fence(ch, run, line.length - t.length, lang)
    }

    private fun isFenceClose(line: String, fence: Fence): Boolean {
        val t = line.trim()
        return t.length >= fence.length && t.all { it == fence.char }
    }

    private fun isBlockStart(line: String): Boolean =
        fenceOpen(line) != null ||
            HEADING.matches(line) ||
            RULE.matches(line) ||
            line.trimStart().startsWith(">") ||
            LIST_ITEM.matches(line)

    private fun isTableStart(lines: List<String>, i: Int): Boolean {
        if (i + 1 >= lines.size) return false
        val header = lines[i]
        val sep = lines[i + 1]
        if (!header.contains('|') || !TABLE_SEPARATOR.matches(sep) || !sep.contains('-')) return false
        return splitRow(header).size == splitRow(sep).size
    }

    private fun splitRow(line: String): List<String> {
        var t = line.trim()
        if (t.startsWith("|")) t = t.substring(1)
        if (t.endsWith("|") && !t.endsWith("\\|")) t = t.dropLast(1)
        val cells = ArrayList<String>()
        val cur = StringBuilder()
        var i = 0
        while (i < t.length) {
            val c = t[i]
            if (c == '\\' && i + 1 < t.length && t[i + 1] == '|') { cur.append('|'); i += 2; continue }
            if (c == '|') { cells.add(cur.toString().trim()); cur.setLength(0) } else cur.append(c)
            i++
        }
        cells.add(cur.toString().trim())
        return cells
    }

    private fun parseLines(lines: List<String>, depth: Int): List<Block> {
        val blocks = ArrayList<Block>()
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            if (line.isBlank()) { i++; continue }

            if (depth >= MAX_DEPTH) {
                blocks.add(Block.Paragraph(InlineParser.parse(line.trim())))
                i++; continue
            }

            val fence = fenceOpen(line)
            if (fence != null) {
                val body = ArrayList<String>()
                var j = i + 1
                while (j < lines.size && !isFenceClose(lines[j], fence)) {
                    val l = lines[j]
                    body.add(l.substring(minOf(fence.indent, leadingSpaces(l))))
                    j++
                }
                val closed = j < lines.size
                blocks.add(Block.CodeBlock(fence.language, body.joinToString("\n"), closed))
                i = if (closed) j + 1 else j
                continue
            }

            val heading = HEADING.matchEntire(line)
            if (heading != null) {
                val text = heading.groupValues[2].replace(HEADING_TRAILING, "").trim()
                if (text.isNotEmpty()) {
                    blocks.add(Block.Heading(heading.groupValues[1].length, InlineParser.parse(text)))
                    i++; continue
                }
            }

            if (RULE.matches(line)) { blocks.add(Block.Rule); i++; continue }

            if (line.trimStart().startsWith(">")) {
                val inner = ArrayList<String>()
                var j = i
                while (j < lines.size && lines[j].trimStart().startsWith(">")) {
                    inner.add(lines[j].trimStart().removePrefix(">").removePrefix(" "))
                    j++
                }
                blocks.add(Block.Quote(parseLines(inner, depth + 1)))
                i = j; continue
            }

            if (LIST_ITEM.matches(line)) {
                val (list, next) = parseList(lines, i, depth)
                blocks.add(list)
                i = next; continue
            }

            if (isTableStart(lines, i)) {
                val header = splitRow(lines[i])
                val aligns = splitRow(lines[i + 1]).map { cell ->
                    val starts = cell.startsWith(":")
                    val ends = cell.endsWith(":")
                    when {
                        starts && ends -> ColumnAlign.CENTER
                        ends -> ColumnAlign.END
                        else -> ColumnAlign.START
                    }
                }
                val rows = ArrayList<List<List<Inline>>>()
                var j = i + 2
                while (j < lines.size && lines[j].isNotBlank() && lines[j].contains('|')) {
                    val cells = splitRow(lines[j])
                    rows.add(List(header.size) { c -> InlineParser.parse(cells.getOrElse(c) { "" }) })
                    j++
                }
                blocks.add(Block.Table(header.map { InlineParser.parse(it) }, aligns, rows))
                i = j; continue
            }

            // Paragraph: runs until a blank line or the start of another block.
            val para = ArrayList<String>()
            var j = i
            while (j < lines.size && lines[j].isNotBlank()) {
                if (j > i && (isBlockStart(lines[j]) || isTableStart(lines, j))) break
                para.add(lines[j].trim())
                j++
            }
            blocks.add(Block.Paragraph(InlineParser.parse(para.joinToString("\n"))))
            i = j
        }
        return blocks
    }

    private fun parseList(lines: List<String>, start: Int, depth: Int): Pair<Block.ListBlock, Int> {
        val first = LIST_ITEM.matchEntire(lines[start])!!
        val baseIndent = first.groupValues[1].length
        val ordered = first.groupValues[2].first().isDigit()
        val startNumber = if (ordered) first.groupValues[2].dropLast(1).toIntOrNull() ?: 1 else 1
        val items = ArrayList<List<Block>>()

        var idx = start
        while (true) {
            // Allow blank lines between items ("loose" lists) as long as the next item continues this list.
            var look = idx
            while (look < lines.size && lines[look].isBlank()) look++
            if (look >= lines.size) break
            val m = LIST_ITEM.matchEntire(lines[look]) ?: break
            val indent = m.groupValues[1].length
            val isOrdered = m.groupValues[2].first().isDigit()
            if (indent != baseIndent || isOrdered != ordered) break

            val marker = m.groupValues[2]
            val contentIndent = indent + marker.length + minOf(m.groupValues[3].length, 4)
            val body = ArrayList<String>()
            body.add(m.groupValues[4])
            idx = look + 1

            while (idx < lines.size) {
                val l = lines[idx]
                if (l.isBlank()) {
                    var k = idx + 1
                    while (k < lines.size && lines[k].isBlank()) k++
                    if (k >= lines.size) break
                    if (leadingSpaces(lines[k]) > baseIndent) {
                        for (b in idx until k) body.add("")
                        idx = k
                        continue
                    }
                    break
                }
                val ind = leadingSpaces(l)
                if (ind > baseIndent) {
                    body.add(l.substring(minOf(ind, contentIndent)))
                    idx++
                    continue
                }
                // Lazy continuation: unindented text directly under an item's text.
                if (body.last().isNotBlank() && !isBlockStart(l)) {
                    body.add(l.trimStart())
                    idx++
                    continue
                }
                break
            }
            items.add(parseLines(body, depth + 1))
        }
        return Block.ListBlock(ordered, startNumber, items) to idx
    }
}
