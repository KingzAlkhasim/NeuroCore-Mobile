package name.kingxtech.neurocore.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** NeuroCore palette: deep midnight surfaces with a violet-to-cyan signature gradient. */
object NC {
    val Night = Color(0xFF07090F)
    val Surface = Color(0xFF111522)
    val SurfaceHigh = Color(0xFF1A2032)
    val Outline = Color(0xFF242B40)

    val Violet = Color(0xFF8B5CF6)
    val Cyan = Color(0xFF38BDF8)
    val Success = Color(0xFF76E3A4)
    val Warning = Color(0xFFFBBF77)
    val Error = Color(0xFFFF8A8A)

    val TextPrimary = Color(0xFFEDEEF5)
    val TextSecondary = Color(0xFFA3ABC3)
    val TextTertiary = Color(0xFF6B7490)

    val UserBubble = Color(0xFF2A2145)
    val CodeBackground = Color(0xFF0B0E19)
    val CodeHeader = Color(0xFF151A2A)
    val InlineCodeBackground = Color(0xFF1E2438)
    val InlineCode = Color(0xFFF2B8E6)

    // Syntax colours
    val SynKeyword = Color(0xFFC792EA)
    val SynString = Color(0xFFA5D98B)
    val SynNumber = Color(0xFFF78C6C)
    val SynComment = Color(0xFF5F6B8A)
    val SynFunction = Color(0xFF82AAFF)
    val SynType = Color(0xFFFFCB6B)
    val SynAnnotation = Color(0xFF89DDFF)
    val SynTag = Color(0xFFF07178)
    val SynAttribute = Color(0xFFFFCB6B)

    val Brand: Brush get() = Brush.linearGradient(listOf(Violet, Cyan))
}

@Composable
fun NeuroCoreTheme(content: @Composable () -> Unit) {
    // NeuroCore is a dark-first design; the palette is the same whatever the system theme says.
    @Suppress("UNUSED_VARIABLE")
    val system = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = NC.Violet,
            onPrimary = Color.White,
            secondary = NC.Cyan,
            onSecondary = Color.Black,
            background = NC.Night,
            onBackground = NC.TextPrimary,
            surface = NC.Surface,
            onSurface = NC.TextPrimary,
            surfaceVariant = NC.SurfaceHigh,
            onSurfaceVariant = NC.TextSecondary,
            outline = NC.Outline,
            outlineVariant = NC.Outline,
            error = NC.Error,
        ),
        content = content,
    )
}
