package name.kingxtech.neurocore.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import name.kingxtech.neurocore.markdown.Block
import name.kingxtech.neurocore.markdown.ColumnAlign
import name.kingxtech.neurocore.markdown.Inline
import name.kingxtech.neurocore.markdown.MarkdownParser
import name.kingxtech.neurocore.markdown.SyntaxHighlighter
import name.kingxtech.neurocore.markdown.TokenType
import name.kingxtech.neurocore.markdown.plainText
import name.kingxtech.neurocore.ui.theme.NC

/**
 * Renders Markdown with native Compose text: headings, lists, quotes, tables, links and
 * syntax-highlighted code blocks with a copy button. [textScale] is the user's response text size.
 */
@Composable
fun MarkdownContent(
    markdown: String,
    textScale: Float,
    onCopyCode: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val blocks = remember(markdown) { MarkdownParser.parse(markdown) }
    Column(modifier, verticalArrangement = Arrangement.spacedBy((10f * textScale).dp)) {
        for (block in blocks) RenderBlock(block, textScale, onCopyCode)
    }
}

@Composable
private fun RenderBlock(block: Block, scale: Float, onCopyCode: (String) -> Unit) {
    when (block) {
        is Block.Paragraph -> InlineText(block.inlines, 16f * scale, 25f * scale)

        is Block.Heading -> {
            val base = when (block.level) {
                1 -> 22f
                2 -> 19.5f
                3 -> 17.5f
                else -> 16.5f
            }
            val size = base * scale
            InlineText(block.inlines, size, size * 1.35f, FontWeight.SemiBold, Color.White)
        }

        is Block.CodeBlock -> CodeBlockView(block.language, block.code, scale, onCopyCode)

        is Block.Quote -> Row(Modifier.height(IntrinsicSize.Min)) {
            Box(
                Modifier
                    .width(3.dp)
                    .fillMaxHeight()
                    .background(NC.Violet.copy(alpha = 0.7f), RoundedCornerShape(2.dp)),
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy((8f * scale).dp)) {
                for (inner in block.blocks) RenderBlock(inner, scale, onCopyCode)
            }
        }

        is Block.ListBlock -> Column(verticalArrangement = Arrangement.spacedBy((6f * scale).dp)) {
            block.items.forEachIndexed { index, itemBlocks ->
                Row {
                    Text(
                        text = if (block.ordered) "${block.start + index}." else "•",
                        color = if (block.ordered) NC.TextSecondary else NC.Cyan,
                        fontSize = (16f * scale).sp,
                        lineHeight = (25f * scale).sp,
                        modifier = Modifier.width(((if (block.ordered) 28f else 18f) * scale).dp),
                    )
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy((6f * scale).dp)) {
                        for (inner in itemBlocks) RenderBlock(inner, scale, onCopyCode)
                    }
                }
            }
        }

        is Block.Table -> TableView(block, scale)

        Block.Rule -> HorizontalDivider(color = NC.Outline)
    }
}

@Composable
private fun InlineText(
    inlines: List<Inline>,
    fontSize: Float,
    lineHeight: Float,
    weight: FontWeight = FontWeight.Normal,
    color: Color = NC.TextPrimary,
    textAlign: TextAlign = TextAlign.Start,
    modifier: Modifier = Modifier,
) {
    val text = remember(inlines, fontSize) { buildInline(inlines, fontSize) }
    Text(
        text = text,
        color = color,
        fontSize = fontSize.sp,
        lineHeight = lineHeight.sp,
        fontWeight = weight,
        textAlign = textAlign,
        modifier = modifier,
    )
}

private fun buildInline(inlines: List<Inline>, fontSize: Float): AnnotatedString =
    buildAnnotatedString { appendInlines(inlines, fontSize) }

private fun AnnotatedString.Builder.appendInlines(inlines: List<Inline>, fontSize: Float) {
    for (node in inlines) {
        when (node) {
            is Inline.Text -> append(node.text)
            is Inline.Code -> withStyle(
                SpanStyle(
                    fontFamily = FontFamily.Monospace,
                    fontSize = (fontSize * 0.88f).sp,
                    color = NC.InlineCode,
                    background = NC.InlineCodeBackground,
                ),
            ) { append(node.code) }
            is Inline.Bold -> withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Color.White)) {
                appendInlines(node.children, fontSize)
            }
            is Inline.Italic -> withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                appendInlines(node.children, fontSize)
            }
            is Inline.Strike -> withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough, color = NC.TextSecondary)) {
                appendInlines(node.children, fontSize)
            }
            is Inline.Link -> withLink(
                LinkAnnotation.Url(
                    node.url,
                    TextLinkStyles(SpanStyle(color = NC.Cyan, textDecoration = TextDecoration.Underline)),
                ),
            ) { appendInlines(node.children, fontSize) }
        }
    }
}

// ---- code ---------------------------------------------------------------------------------------

private fun colorFor(type: TokenType): Color = when (type) {
    TokenType.Keyword -> NC.SynKeyword
    TokenType.String -> NC.SynString
    TokenType.Number -> NC.SynNumber
    TokenType.Comment -> NC.SynComment
    TokenType.Function -> NC.SynFunction
    TokenType.Type -> NC.SynType
    TokenType.Annotation -> NC.SynAnnotation
    TokenType.Tag -> NC.SynTag
    TokenType.Attribute -> NC.SynAttribute
}

private fun highlight(code: String, language: String?): AnnotatedString = buildAnnotatedString {
    append(code)
    for (token in SyntaxHighlighter.highlight(code, language)) {
        val style = if (token.type == TokenType.Comment) {
            SpanStyle(color = colorFor(token.type), fontStyle = FontStyle.Italic)
        } else {
            SpanStyle(color = colorFor(token.type))
        }
        addStyle(style, token.start, token.end)
    }
}

@Composable
private fun CodeBlockView(language: String?, code: String, scale: Float, onCopy: (String) -> Unit) {
    val highlighted = remember(code, language) { highlight(code, language) }
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1600)
            copied = false
        }
    }
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(NC.CodeBackground)
            .border(1.dp, NC.Outline, shape),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(NC.CodeHeader)
                .padding(start = 14.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = language ?: "code",
                color = NC.TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.weight(1f),
            )
            TextButton(
                onClick = { onCopy(code); copied = true },
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                colors = ButtonDefaults.textButtonColors(contentColor = if (copied) NC.Success else NC.TextSecondary),
            ) {
                Icon(
                    if (copied) Icons.Rounded.Check else Icons.Rounded.ContentCopy,
                    contentDescription = null,
                    modifier = Modifier.size(15.dp),
                )
                Spacer(Modifier.width(6.dp))
                Text(if (copied) "Copied" else "Copy", fontSize = 12.sp)
            }
        }
        Box(
            Modifier
                .horizontalScroll(rememberScrollState())
                .padding(14.dp),
        ) {
            Text(
                text = highlighted,
                color = NC.TextPrimary,
                fontFamily = FontFamily.Monospace,
                fontSize = (13f * scale).sp,
                lineHeight = (20f * scale).sp,
                softWrap = false,
            )
        }
    }
}

// ---- tables -------------------------------------------------------------------------------------

@Composable
private fun TableView(table: Block.Table, scale: Float) {
    val widths = remember(table) {
        table.header.indices.map { c ->
            val longest = (listOf(table.header[c]) + table.rows.map { it.getOrElse(c) { emptyList() } })
                .maxOf { it.plainText().lines().maxOfOrNull { line -> line.length } ?: 0 }
            longest.coerceIn(4, 30) * 8.5f + 28f
        }
    }
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier
            .clip(shape)
            .border(BorderStroke(1.dp, NC.Outline), shape)
            .horizontalScroll(rememberScrollState()),
    ) {
        TableRow(table.header, table.aligns, widths, scale, header = true)
        for (row in table.rows) {
            HorizontalDivider(color = NC.Outline)
            TableRow(row, table.aligns, widths, scale, header = false)
        }
    }
}

@Composable
private fun TableRow(
    cells: List<List<Inline>>,
    aligns: List<ColumnAlign>,
    widths: List<Float>,
    scale: Float,
    header: Boolean,
) {
    Row(Modifier.background(if (header) NC.SurfaceHigh else Color.Transparent)) {
        cells.forEachIndexed { c, cell ->
            val align = when (aligns.getOrElse(c) { ColumnAlign.START }) {
                ColumnAlign.START -> TextAlign.Start
                ColumnAlign.CENTER -> TextAlign.Center
                ColumnAlign.END -> TextAlign.End
            }
            Box(
                Modifier
                    .width((widths.getOrElse(c) { 80f } * scale).dp)
                    .padding(horizontal = 12.dp, vertical = 9.dp),
            ) {
                InlineText(
                    inlines = cell,
                    fontSize = 14.5f * scale,
                    lineHeight = 21f * scale,
                    weight = if (header) FontWeight.SemiBold else FontWeight.Normal,
                    color = if (header) Color.White else NC.TextPrimary,
                    textAlign = align,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}
