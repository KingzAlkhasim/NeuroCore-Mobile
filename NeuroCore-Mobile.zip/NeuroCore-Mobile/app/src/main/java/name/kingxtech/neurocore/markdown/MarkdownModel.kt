package name.kingxtech.neurocore.markdown

/** Inline (within a line) Markdown nodes. */
sealed interface Inline {
    data class Text(val text: String) : Inline
    data class Code(val code: String) : Inline
    data class Bold(val children: List<Inline>) : Inline
    data class Italic(val children: List<Inline>) : Inline
    data class Strike(val children: List<Inline>) : Inline
    data class Link(val children: List<Inline>, val url: String) : Inline
}

enum class ColumnAlign { START, CENTER, END }

/** Block level Markdown nodes. */
sealed interface Block {
    data class Paragraph(val inlines: List<Inline>) : Block
    data class Heading(val level: Int, val inlines: List<Inline>) : Block
    data class CodeBlock(val language: String?, val code: String, val closed: Boolean) : Block
    data class Quote(val blocks: List<Block>) : Block
    data class ListBlock(val ordered: Boolean, val start: Int, val items: List<List<Block>>) : Block
    data class Table(
        val header: List<List<Inline>>,
        val aligns: List<ColumnAlign>,
        val rows: List<List<List<Inline>>>,
    ) : Block
    object Rule : Block
}

/** Flattens inline nodes to plain text (used for table sizing and text to speech). */
fun List<Inline>.plainText(): String {
    val sb = StringBuilder()
    fun walk(nodes: List<Inline>) {
        for (n in nodes) when (n) {
            is Inline.Text -> sb.append(n.text)
            is Inline.Code -> sb.append(n.code)
            is Inline.Bold -> walk(n.children)
            is Inline.Italic -> walk(n.children)
            is Inline.Strike -> walk(n.children)
            is Inline.Link -> walk(n.children)
        }
    }
    walk(this)
    return sb.toString()
}
