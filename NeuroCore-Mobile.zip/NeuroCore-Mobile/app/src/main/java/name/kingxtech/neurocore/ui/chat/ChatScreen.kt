package name.kingxtech.neurocore.ui.chat

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import name.kingxtech.neurocore.EngineStatus
import name.kingxtech.neurocore.ChatUiState
import name.kingxtech.neurocore.data.ChatMessage
import name.kingxtech.neurocore.engine.DownloadMath
import name.kingxtech.neurocore.engine.ModelConfig
import name.kingxtech.neurocore.ui.components.LogoBadge
import name.kingxtech.neurocore.ui.components.MarkdownContent
import name.kingxtech.neurocore.ui.components.PulsingDot
import name.kingxtech.neurocore.ui.components.StaticDot
import name.kingxtech.neurocore.ui.components.TypingIndicator
import name.kingxtech.neurocore.ui.theme.NC
import name.kingxtech.neurocore.data.Role as ChatRole

@Composable
fun ChatScreen(
    state: ChatUiState,
    textScale: Float,
    speakingId: Long?,
    onSend: (String) -> Unit,
    onStop: () -> Unit,
    onRegenerate: () -> Unit,
    onNewChat: () -> Unit,
    onOpenSettings: () -> Unit,
    onCopyMessage: (String) -> Unit,
    onCopyCode: (String) -> Unit,
    onToggleSpeak: (ChatMessage) -> Unit,
    onRetryEngine: () -> Unit,
    onDownload: () -> Unit,
    onCancelDownload: () -> Unit,
) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        ChatTopBar(state, onNewChat, onOpenSettings)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (val engine = state.engine) {
                is EngineStatus.Preparing -> PreparingPane(engine)
                is EngineStatus.NeedsModel -> DownloadPane(engine, onDownload)
                is EngineStatus.Downloading -> DownloadingPane(engine, onCancelDownload)
                is EngineStatus.Failed -> FailedPane(engine, onRetryEngine)
                EngineStatus.Ready -> if (state.messages.isEmpty()) {
                    EmptyState(onPick = onSend)
                } else {
                    MessageList(state, textScale, speakingId, onRegenerate, onCopyMessage, onCopyCode, onToggleSpeak)
                }
            }
        }
        Composer(
            enabled = state.engine is EngineStatus.Ready,
            generating = state.generating,
            onSend = onSend,
            onStop = onStop,
        )
    }
}

// ---- top bar ------------------------------------------------------------------------------------

@Composable
private fun ChatTopBar(state: ChatUiState, onNewChat: () -> Unit, onOpenSettings: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(start = 18.dp, end = 8.dp, top = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LogoBadge(38.dp)
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text("NeuroCore", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                when {
                    state.engine is EngineStatus.Preparing -> {
                        PulsingDot(NC.Warning)
                        Spacer(Modifier.size(7.dp))
                        Text("Getting ready…", color = NC.TextSecondary, fontSize = 12.sp)
                    }
                    state.engine is EngineStatus.NeedsModel || state.engine is EngineStatus.Downloading -> {
                        PulsingDot(NC.Warning)
                        Spacer(Modifier.size(7.dp))
                        Text(
                            if (state.engine is EngineStatus.Downloading) "Downloading model…" else "Model needed",
                            color = NC.TextSecondary,
                            fontSize = 12.sp,
                        )
                    }
                    state.engine is EngineStatus.Failed -> {
                        StaticDot(NC.Error)
                        Spacer(Modifier.size(7.dp))
                        Text("Unavailable", color = NC.TextSecondary, fontSize = 12.sp)
                    }
                    state.generating -> {
                        PulsingDot(NC.Cyan)
                        Spacer(Modifier.size(7.dp))
                        Text("Thinking on-device…", color = NC.TextSecondary, fontSize = 12.sp)
                    }
                    else -> {
                        StaticDot(NC.Success)
                        Spacer(Modifier.size(7.dp))
                        Text("Private · works offline", color = NC.TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        }
        IconButton(onClick = onNewChat, enabled = state.messages.isNotEmpty()) {
            Icon(
                Icons.Rounded.Add,
                contentDescription = "New chat",
                tint = if (state.messages.isNotEmpty()) NC.TextPrimary else NC.TextTertiary,
            )
        }
        IconButton(onClick = onOpenSettings) {
            Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = NC.TextPrimary)
        }
    }
}

// ---- messages -----------------------------------------------------------------------------------

@Composable
private fun MessageList(
    state: ChatUiState,
    textScale: Float,
    speakingId: Long?,
    onRegenerate: () -> Unit,
    onCopyMessage: (String) -> Unit,
    onCopyCode: (String) -> Unit,
    onToggleSpeak: (ChatMessage) -> Unit,
) {
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var follow by remember { mutableStateOf(true) }

    val connection = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                // The user dragged towards older messages: stop auto-following the stream.
                if (source == NestedScrollSource.UserInput && available.y > 0f) follow = false
                return Offset.Zero
            }
        }
    }

    val lastIndex = state.messages.size // the trailing spacer item
    val lastText = state.messages.lastOrNull()?.text?.length ?: 0

    LaunchedEffect(state.messages.size) { follow = true }
    LaunchedEffect(state.messages.size, lastText, follow) {
        if (follow) listState.scrollToItem(lastIndex)
    }
    LaunchedEffect(listState.canScrollForward) {
        if (!listState.canScrollForward) follow = true
    }

    val lastAssistantId = state.messages.lastOrNull { it.role == ChatRole.ASSISTANT }?.id

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().nestedScroll(connection),
            contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp),
        ) {
            items(state.messages, key = { it.id }) { message ->
                if (message.role == ChatRole.USER) {
                    UserMessage(message, textScale)
                } else {
                    AssistantMessage(
                        message = message,
                        textScale = textScale,
                        streaming = state.streamingId == message.id,
                        generating = state.generating,
                        speaking = speakingId == message.id,
                        isLast = message.id == lastAssistantId,
                        onCopy = { onCopyMessage(message.text) },
                        onCopyCode = onCopyCode,
                        onSpeak = { onToggleSpeak(message) },
                        onRegenerate = onRegenerate,
                    )
                }
            }
            item(key = "bottom-spacer") { Spacer(Modifier.height(4.dp)) }
        }

        AnimatedVisibility(
            visible = !follow && listState.canScrollForward,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp),
        ) {
            Surface(
                onClick = {
                    follow = true
                    scope.launch { listState.scrollToItem(lastIndex) }
                },
                shape = CircleShape,
                color = NC.SurfaceHigh,
                border = BorderStroke(1.dp, NC.Outline),
            ) {
                Icon(
                    Icons.Rounded.ExpandMore,
                    contentDescription = "Scroll to latest",
                    tint = NC.TextPrimary,
                    modifier = Modifier.padding(8.dp).size(22.dp),
                )
            }
        }
    }
}

@Composable
private fun UserMessage(message: ChatMessage, textScale: Float) {
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
        Surface(
            color = NC.UserBubble,
            shape = RoundedCornerShape(22.dp, 22.dp, 6.dp, 22.dp),
            modifier = Modifier.widthIn(max = 330.dp),
        ) {
            Text(
                text = message.text,
                color = NC.TextPrimary,
                fontSize = (16f * textScale).sp,
                lineHeight = (24f * textScale).sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            )
        }
    }
}

@Composable
private fun AssistantMessage(
    message: ChatMessage,
    textScale: Float,
    streaming: Boolean,
    generating: Boolean,
    speaking: Boolean,
    isLast: Boolean,
    onCopy: () -> Unit,
    onCopyCode: (String) -> Unit,
    onSpeak: () -> Unit,
    onRegenerate: () -> Unit,
) {
    Row(Modifier.fillMaxWidth()) {
        LogoBadge(28.dp, Modifier.padding(top = 2.dp))
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            when {
                message.text.isEmpty() -> TypingIndicator(Modifier.padding(top = 10.dp, bottom = 6.dp))
                message.isError -> Text(
                    text = message.text,
                    color = NC.Error,
                    fontSize = (15f * textScale).sp,
                    lineHeight = (22f * textScale).sp,
                )
                else -> MarkdownContent(message.text, textScale, onCopyCode)
            }
            if (!streaming && message.text.isNotEmpty()) {
                Row(
                    Modifier.padding(top = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (!message.isError) {
                        ActionIcon(Icons.Rounded.ContentCopy, "Copy reply", onCopy)
                        ActionIcon(
                            if (speaking) Icons.Rounded.Stop else Icons.Rounded.VolumeUp,
                            if (speaking) "Stop reading" else "Read aloud",
                            onSpeak,
                            tint = if (speaking) NC.Cyan else NC.TextTertiary,
                        )
                    }
                    if (isLast && !generating) ActionIcon(Icons.Rounded.Refresh, "Regenerate", onRegenerate)
                    if (message.stats != null) {
                        Spacer(Modifier.size(6.dp))
                        Text(message.stats, color = NC.TextTertiary, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionIcon(icon: ImageVector, description: String, onClick: () -> Unit, tint: Color = NC.TextTertiary) {
    IconButton(onClick = onClick, modifier = Modifier.size(36.dp)) {
        Icon(icon, contentDescription = description, tint = tint, modifier = Modifier.size(18.dp))
    }
}

// ---- empty and status panes ---------------------------------------------------------------------

private data class Suggestion(val icon: ImageVector, val label: String, val prompt: String)

private val suggestions = listOf(
    Suggestion(Icons.Rounded.Lightbulb, "Explain an idea", "Explain how neural networks learn, in simple terms."),
    Suggestion(Icons.Rounded.Code, "Write some code", "Write a Kotlin function that debounces a callback, with a short example."),
    Suggestion(Icons.Rounded.EditNote, "Plan my week", "Help me plan a focused 3-day study schedule as a table."),
    Suggestion(Icons.Rounded.AutoAwesome, "Spark ideas", "Give me 5 creative app ideas that work fully offline."),
)

@Composable
private fun EmptyState(onPick: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        LogoBadge(68.dp)
        Spacer(Modifier.height(22.dp))
        Text("What can I help with?", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(
            "Everything runs on this phone. No account, no internet.",
            color = NC.TextSecondary,
            fontSize = 15.sp,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(30.dp))
        for (row in suggestions.chunked(2)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                for (s in row) SuggestionCard(s, Modifier.weight(1f), onPick)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun SuggestionCard(s: Suggestion, modifier: Modifier, onPick: (String) -> Unit) {
    Surface(
        onClick = { onPick(s.prompt) },
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = NC.Surface,
        border = BorderStroke(1.dp, NC.Outline),
    ) {
        Column(Modifier.padding(16.dp)) {
            Icon(s.icon, contentDescription = null, tint = NC.Cyan, modifier = Modifier.size(22.dp))
            Spacer(Modifier.height(14.dp))
            Text(s.label, color = NC.TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun PreparingPane(status: EngineStatus.Preparing) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 36.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        LogoBadge(64.dp)
        Spacer(Modifier.height(26.dp))
        Text("Preparing your private AI", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(status.label, color = NC.TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(26.dp))
        LinearProgressIndicator(
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
            color = NC.Violet,
            trackColor = NC.Outline,
        )
    }
}

@Composable
private fun DownloadPane(status: EngineStatus.NeedsModel, onDownload: () -> Unit) {
    val resuming = status.partialBytes > 0L
    Column(
        Modifier.fillMaxSize().padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(Modifier.size(68.dp).background(NC.Brand, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.CloudDownload, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text("Download the AI model", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(
            "NeuroCore needs to download its model once (about ${DownloadMath.formatBytes(ModelConfig.APPROX_SIZE_BYTES)}). " +
                "Wi-Fi is recommended. After that it works completely offline.",
            color = NC.TextSecondary,
            fontSize = 14.sp,
            lineHeight = 21.sp,
            textAlign = TextAlign.Center,
        )
        if (status.message != null) {
            Spacer(Modifier.height(14.dp))
            Text(status.message, color = NC.Warning, fontSize = 13.sp, lineHeight = 19.sp, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(26.dp))
        Button(
            onClick = onDownload,
            colors = ButtonDefaults.buttonColors(containerColor = NC.Violet, contentColor = Color.White),
        ) {
            Text(
                if (resuming) "Resume download (${DownloadMath.formatBytes(status.partialBytes)} saved)" else "Download model",
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "${ModelConfig.DISPLAY_NAME} · ${ModelConfig.QUANTIZATION}",
            color = NC.TextTertiary,
            fontSize = 12.sp,
        )
    }
}

@Composable
private fun DownloadingPane(status: EngineStatus.Downloading, onCancel: () -> Unit) {
    // Keep the screen awake so the download isn't interrupted by the display turning off.
    val view = LocalView.current
    DisposableEffect(view) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    val fraction = DownloadMath.fraction(status.downloaded, status.total)
    Column(
        Modifier.fillMaxSize().padding(horizontal = 36.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        LogoBadge(64.dp)
        Spacer(Modifier.height(26.dp))
        Text("Downloading your AI", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(
            "${DownloadMath.formatBytes(status.downloaded)} of ${DownloadMath.formatBytes(status.total)}",
            color = NC.TextSecondary,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(26.dp))
        LinearProgressIndicator(
            progress = { fraction },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
            color = NC.Violet,
            trackColor = NC.Outline,
        )
        Spacer(Modifier.height(10.dp))
        Text("${(fraction * 100).toInt()}%", color = NC.TextTertiary, fontSize = 13.sp)
        Spacer(Modifier.height(26.dp))
        OutlinedButton(onClick = onCancel) { Text("Pause", color = NC.TextPrimary) }
        Spacer(Modifier.height(14.dp))
        Text(
            "Keep NeuroCore open. If it stops, you can resume later.",
            color = NC.TextTertiary,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun FailedPane(status: EngineStatus.Failed, onRetry: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(Modifier.size(64.dp).background(NC.SurfaceHigh, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Memory, contentDescription = null, tint = NC.Warning, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(22.dp))
        Text(status.title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(status.message, color = NC.TextSecondary, fontSize = 14.sp, lineHeight = 21.sp, textAlign = TextAlign.Center)
        if (status.canRetry) {
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = NC.Violet, contentColor = Color.White),
            ) { Text("Try again") }
        }
    }
}

// ---- composer -----------------------------------------------------------------------------------

@Composable
private fun Composer(enabled: Boolean, generating: Boolean, onSend: (String) -> Unit, onStop: () -> Unit) {
    var text by rememberSaveable { mutableStateOf("") }
    val canSend = enabled && !generating && text.isNotBlank()
    val shape = RoundedCornerShape(28.dp)

    Row(
        Modifier
            .navigationBarsPadding()
            .imePadding()
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .fillMaxWidth()
            .background(NC.Surface, shape)
            .border(1.dp, NC.Outline, shape)
            .padding(start = 18.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        Box(Modifier.weight(1f).padding(vertical = 11.dp)) {
            if (text.isEmpty()) {
                Text(
                    if (enabled) "Message NeuroCore" else "Getting ready…",
                    color = NC.TextTertiary,
                    fontSize = 16.sp,
                )
            }
            BasicTextField(
                value = text,
                onValueChange = { text = it },
                enabled = enabled,
                textStyle = TextStyle(color = NC.TextPrimary, fontSize = 16.sp, lineHeight = 22.sp),
                cursorBrush = SolidColor(NC.Cyan),
                maxLines = 6,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        val buttonModifier = Modifier.size(44.dp).clip(CircleShape)
        when {
            generating -> Box(
                buttonModifier
                    .background(NC.SurfaceHigh)
                    .clickable(role = Role.Button, onClickLabel = "Stop generating") { onStop() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.Stop, contentDescription = "Stop", tint = Color.White, modifier = Modifier.size(22.dp))
            }
            else -> Box(
                (if (canSend) buttonModifier.background(NC.Brand) else buttonModifier.background(NC.SurfaceHigh))
                    .clickable(enabled = canSend, role = Role.Button, onClickLabel = "Send") {
                        onSend(text)
                        text = ""
                    },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Rounded.ArrowUpward,
                    contentDescription = "Send",
                    tint = if (canSend) Color.White else NC.TextTertiary,
                    modifier = Modifier.size(22.dp),
                )
            }
        }
    }
}
