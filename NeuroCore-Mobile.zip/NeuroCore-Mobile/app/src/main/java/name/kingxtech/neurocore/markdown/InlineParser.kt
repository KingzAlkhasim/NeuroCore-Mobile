package name.kingxtech.neurocore.markdown

/**
 * A forgiving inline Markdown parser tuned for LLM output. Anything it cannot close stays literal,
 * which is exactly what you want while a response is still streaming in.
 */
object InlineParser {
    private const val ESCAPABLE = "\\`*_{}[]()#+-.!|~<>"

    fun parse(text: String): List<Inline> {
        val out = ArrayList<Inline>()
        val buf = StringBuilder()
        val n = text.length

        fun flush() {
            if (buf.isNotEmpty()) {
                out.add(Inline.Text(buf.toString()))
                buf.setLength(0)
            }
        }

        var i = 0
        while (i < n) {
            val c = text[i]

            if (c == '\\' && i + 1 < n && ESCAPABLE.indexOf(text[i + 1]) >= 0) {
                buf.append(text[i + 1]); i += 2; continue
            }

            if (c == '<' && text.startsWith("<br", i, ignoreCase = true)) {
                val close = text.indexOf('>', i)
                if (close > 0 && close <= i + 6) {
                    val mid = text.substring(i + 3, close).trim()
                    if (mid.isEmpty() || mid == "/") { buf.append('\n'); i = close + 1; continue }
                }
            }

            if (c == '`') {
                var run = 1
                while (i + run < n && text[i + run] == '`') run++
                val close = findBacktickClose(text, i + run, run)
                if (close >= 0) {
                    flush()
                    var code = text.substring(i + run, close)
                    if (code.length >= 2 && code.startsWith(" ") && code.endsWith(" ") && code.isNotBlank()) {
                        code = code.substring(1, code.length - 1)
                    }
                    out.add(Inline.Code(code))
                    i = close + run
                } else {
                    repeat(run) { buf.append('`') }
                    i += run
                }
                continue
            }

            if ((c == '*' || c == '_') && i + 1 < n && text[i + 1] == c) {
                val end = parseBold(text, i, c)
                if (end != null) {
                    flush(); out.add(Inline.Bold(parse(end.first))); i = end.second
                } else {
                    buf.append(c).append(c); i += 2
                }
                continue
            }

            if (c == '~' && i + 1 < n && text[i + 1] == '~') {
                val j = i + 2
                if (j < n && !text[j].isWhitespace()) {
                    val k = findClose(text, j) { pos -> text.startsWith("~~", pos) && pos > j && !text[pos - 1].isWhitespace() }
                    if (k >= 0) {
                        flush(); out.add(Inline.Strike(parse(text.substring(j, k)))); i = k + 2; continue
                    }
                }
                buf.append("~~"); i += 2; continue
            }

            if (c == '*' || c == '_') {
                val end = parseItalic(text, i, c)
                if (end != null) {
                    flush(); out.add(Inline.Italic(parse(end.first))); i = end.second
                } else {
                    buf.append(c); i++
                }
                continue
            }

            if (c == '!' && i + 1 < n && text[i + 1] == '[') {
                val link = parseLink(text, i + 1)
                if (link != null) {
                    // Images are never fetched (the app is offline); show the alt text instead.
                    buf.append(link.label); i = link.end; continue
                }
            }

            if (c == '[') {
                val link = parseLink(text, i)
                if (link != null) {
                    flush(); out.add(Inline.Link(parse(link.label), link.url)); i = link.end; continue
                }
            }

            if (c == '<' && (text.startsWith("<http://", i) || text.startsWith("<https://", i))) {
                val close = text.indexOf('>', i)
                if (close > 0) {
                    val url = text.substring(i + 1, close)
                    if (url.none { it.isWhitespace() }) {
                        flush(); out.add(Inline.Link(listOf(Inline.Text(url)), url)); i = close + 1; continue
                    }
                }
            }

            if (c == 'h' && (text.startsWith("http://", i) || text.startsWith("https://", i)) &&
                (i == 0 || !text[i - 1].isLetterOrDigit())
            ) {
                var end = i
                while (end < n && !text[end].isWhitespace() && text[end] != '<') end++
                while (end > i && ".,;:!?'\"]}".indexOf(text[end - 1]) >= 0) end--
                while (end > i && text[end - 1] == ')' && !text.substring(i, end).contains('(')) end--
                val url = text.substring(i, end)
                if (url.length > 8) {
                    flush(); out.add(Inline.Link(listOf(Inline.Text(url)), url)); i = end; continue
                }
            }

            buf.append(c); i++
        }
        flush()
        return out
    }

    private fun findBacktickClose(text: String, from: Int, run: Int): Int {
        var k = from
        while (k < text.length) {
            if (text[k] == '`') {
                var r = 1
                while (k + r < text.length && text[k + r] == '`') r++
                if (r == run) return k
                k += r
            } else k++
        }
        return -1
    }

    /** Scans for a closing marker, skipping escapes and code spans. */
    private inline fun findClose(text: String, from: Int, matcher: (Int) -> Boolean): Int {
        var k = from
        while (k < text.length) {
            val ch = text[k]
            if (ch == '\\') { k += 2; continue }
            if (ch == '`') {
                val e = text.indexOf('`', k + 1)
                if (e >= 0) { k = e + 1; continue }
            }
            if (matcher(k)) return k
            k++
        }
        return -1
    }

    private fun parseBold(text: String, i: Int, marker: Char): Pair<String, Int>? {
        val n = text.length
        val j = i + 2
        if (j >= n || text[j].isWhitespace()) return null
        if (marker == '_' && i > 0 && text[i - 1].isLetterOrDigit()) return null
        val closer = "$marker$marker"
        var k = findClose(text, j) { pos ->
            text.startsWith(closer, pos) && pos > j && !text[pos - 1].isWhitespace() &&
                (marker != '_' || pos + 2 >= n || !text[pos + 2].isLetterOrDigit())
        }
        if (k < 0) return null
        // "***bold italic***": close on the last two characters of the run.
        while (k + 2 < n && text[k + 2] == marker) k++
        return text.substring(j, k) to (k + 2)
    }

    private fun parseItalic(text: String, i: Int, marker: Char): Pair<String, Int>? {
        val n = text.length
        val j = i + 1
        if (j >= n || text[j].isWhitespace() || text[j] == marker) return null
        if (marker == '_' && i > 0 && text[i - 1].isLetterOrDigit()) return null
        val k = findClose(text, j) { pos ->
            text[pos] == marker && pos > j && !text[pos - 1].isWhitespace() && text[pos - 1] != marker &&
                (pos + 1 >= n || text[pos + 1] != marker) &&
                (marker != '_' || pos + 1 >= n || !text[pos + 1].isLetterOrDigit())
        }
        if (k < 0) return null
        return text.substring(j, k) to (k + 1)
    }

    private class LinkMatch(val label: String, val url: String, val end: Int)

    private fun parseLink(text: String, open: Int): LinkMatch? {
        val n = text.length
        var depth = 0
        var k = open
        var closeBracket = -1
        while (k < n) {
            val ch = text[k]
            if (ch == '\\') { k += 2; continue }
            if (ch == '[') depth++
            else if (ch == ']') { depth--; if (depth == 0) { closeBracket = k; break } }
            k++
        }
        if (closeBracket < 0 || closeBracket + 1 >= n || text[closeBracket + 1] != '(') return null
        var pd = 0
        var p = closeBracket + 1
        var closeParen = -1
        while (p < n) {
            val ch = text[p]
            if (ch == '(') pd++
            else if (ch == ')') { pd--; if (pd == 0) { closeParen = p; break } }
            else if (ch == '\n') return null
            p++
        }
        if (closeParen < 0) return null
        val inside = text.substring(closeBracket + 2, closeParen).trim()
        val url = inside.split(Regex("\\s+"), limit = 2).firstOrNull()?.trim('<', '>') ?: return null
        if (url.isEmpty()) return null
        return LinkMatch(text.substring(open + 1, closeBracket), url, closeParen + 1)
    }
}
