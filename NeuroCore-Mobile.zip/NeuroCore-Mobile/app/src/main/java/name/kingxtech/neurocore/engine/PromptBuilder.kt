package name.kingxtech.neurocore.engine

/** Builds Qwen2.5 style ChatML prompts and keeps conversations inside the context window. */
object PromptBuilder {
    const val SYSTEM_PROMPT =
        "You are NeuroCore, a friendly and knowledgeable AI assistant running privately on the user's phone. " +
            "Answer clearly and concisely. Use Markdown for structure, and always put code in fenced code blocks " +
            "with a language tag. If you are unsure, say so instead of guessing."

    /** Rough per-message overhead for the ChatML role markers. */
    private const val MESSAGE_OVERHEAD = 8

    data class Turn(val role: String, val text: String)

    fun build(turns: List<Turn>, systemPrompt: String = SYSTEM_PROMPT): String {
        val sb = StringBuilder()
        sb.append("<|im_start|>system\n").append(systemPrompt).append("<|im_end|>\n")
        for (t in turns) {
            sb.append("<|im_start|>").append(t.role).append('\n').append(t.text).append("<|im_end|>\n")
        }
        sb.append("<|im_start|>assistant\n")
        return sb.toString()
    }

    /**
     * Drops the oldest turns until the prompt fits [budgetTokens]. The conversation always starts with
     * a user turn, and a single oversized message is shortened (keeping its most recent part).
     */
    fun trim(
        turns: List<Turn>,
        budgetTokens: Int,
        systemPrompt: String = SYSTEM_PROMPT,
        countTokens: (String) -> Int,
    ): List<Turn> {
        if (turns.isEmpty()) return turns
        val fixed = countTokens(systemPrompt) + MESSAGE_OVERHEAD + 4
        val costs = turns.map { countTokens(it.text) + MESSAGE_OVERHEAD }.toMutableList()
        var start = 0
        var total = fixed + costs.sum()
        while (total > budgetTokens && start < turns.size - 1) {
            total -= costs[start]
            start++
        }
        while (start < turns.size - 1 && turns[start].role != "user") {
            total -= costs[start]
            start++
        }
        val kept = turns.subList(start, turns.size).toMutableList()
        if (total > budgetTokens && kept.isNotEmpty()) {
            val last = kept.last()
            val available = (budgetTokens - fixed - MESSAGE_OVERHEAD).coerceAtLeast(16)
            val cost = (total - fixed - MESSAGE_OVERHEAD).coerceAtLeast(1)
            val keepChars = (last.text.length.toLong() * available / cost * 9 / 10).toInt().coerceIn(32, last.text.length)
            kept[kept.size - 1] = last.copy(text = last.text.takeLast(keepChars))
        }
        return kept
    }
}
