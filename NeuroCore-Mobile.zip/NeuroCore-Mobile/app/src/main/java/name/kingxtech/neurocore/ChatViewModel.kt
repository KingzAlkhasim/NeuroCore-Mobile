package name.kingxtech.neurocore

import android.app.Application
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import name.kingxtech.neurocore.data.AppSettings
import name.kingxtech.neurocore.data.ChatMessage
import name.kingxtech.neurocore.data.ChatStore
import name.kingxtech.neurocore.data.Role
import name.kingxtech.neurocore.data.SettingsRepository
import name.kingxtech.neurocore.engine.LlamaEngine
import name.kingxtech.neurocore.engine.ModelConfig
import name.kingxtech.neurocore.engine.ModelProvisioner
import name.kingxtech.neurocore.engine.PromptBuilder
import name.kingxtech.neurocore.engine.DownloadResult
import name.kingxtech.neurocore.engine.TokenListener
import name.kingxtech.neurocore.engine.Utf8StreamDecoder
import name.kingxtech.neurocore.tts.SpeechController
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

sealed interface EngineStatus {
    data class Preparing(val label: String) : EngineStatus
    /** The model isn't on the phone yet. [partialBytes] > 0 means a paused download can be resumed. */
    data class NeedsModel(val partialBytes: Long, val message: String? = null) : EngineStatus
    data class Downloading(val downloaded: Long, val total: Long) : EngineStatus
    object Ready : EngineStatus
    data class Failed(val title: String, val message: String, val canRetry: Boolean) : EngineStatus
}

data class ChatUiState(
    val engine: EngineStatus = EngineStatus.Preparing("Starting…"),
    val messages: List<ChatMessage> = emptyList(),
    val generating: Boolean = false,
    val streamingId: Long? = null,
)

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val settingsRepository = SettingsRepository(app)
    private val store = ChatStore(app)
    private val provisioner = ModelProvisioner(app)
    private val engine = LlamaEngine()

    val speech = SpeechController(app)
    val settings: StateFlow<AppSettings> = settingsRepository.settings

    // The native model is not thread safe, so all work on it runs on one dedicated thread.
    private val engineExecutor = Executors.newSingleThreadExecutor { r -> Thread(r, "neurocore-engine") }
    private val engineDispatcher = engineExecutor.asCoroutineDispatcher()

    private val state = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = state.asStateFlow()

    private val idCounter = AtomicLong(0)
    private var engineJob: Job? = null
    private var downloadJob: Job? = null
    private var generationJob: Job? = null
    private var activeStop: AtomicBoolean? = null

    init {
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) { store.load() }
            if (saved.isNotEmpty()) state.update { it.copy(messages = saved) }
        }
        startEngine()
    }

    private fun nextId(): Long {
        while (true) {
            val prev = idCounter.get()
            val next = maxOf(System.currentTimeMillis(), prev + 1)
            if (idCounter.compareAndSet(prev, next)) return next
        }
    }

    // ---- engine lifecycle -------------------------------------------------------------------------

    fun retryEngine() = startEngine()

    private fun startEngine() {
        engineJob?.cancel()
        engineJob = viewModelScope.launch {
            state.update { it.copy(engine = EngineStatus.Preparing("Checking for the AI model…")) }
            val file = withContext(Dispatchers.IO) { provisioner.locate() }
            if (file != null) {
                loadModel(file.absolutePath)
            } else {
                val partial = withContext(Dispatchers.IO) { provisioner.partialBytes() }
                state.update { it.copy(engine = EngineStatus.NeedsModel(partial)) }
            }
        }
    }

    /** Starts (or resumes) the one-time model download. */
    fun downloadModel() {
        val current = state.value.engine
        if (current !is EngineStatus.NeedsModel) return
        downloadJob?.cancel()
        downloadJob = viewModelScope.launch {
            state.update { it.copy(engine = EngineStatus.Downloading(current.partialBytes, ModelConfig.APPROX_SIZE_BYTES)) }
            val result = try {
                provisioner.download { downloaded, total ->
                    state.update { s ->
                        if (s.engine is EngineStatus.Downloading) s.copy(engine = EngineStatus.Downloading(downloaded, total)) else s
                    }
                }
            } catch (e: CancellationException) {
                state.update { it.copy(engine = EngineStatus.NeedsModel(provisioner.partialBytes())) }
                throw e
            }
            when (result) {
                is DownloadResult.Success -> loadModel(result.file.absolutePath)
                is DownloadResult.Failure -> state.update {
                    it.copy(engine = EngineStatus.NeedsModel(provisioner.partialBytes(), result.message))
                }
            }
        }
    }

    /** Pauses the download. The partial file is kept so it can be resumed later. */
    fun cancelDownload() {
        downloadJob?.cancel()
    }

    private suspend fun loadModel(path: String) {
        state.update { it.copy(engine = EngineStatus.Preparing("Waking up the model…")) }
        val cores = Runtime.getRuntime().availableProcessors()
        val threads = (cores / 2).coerceIn(2, 4)
        val outcome = withContext(engineDispatcher) {
            runCatching { engine.load(path, ModelConfig.CONTEXT_SIZE, threads) }
        }
        val error = outcome.exceptionOrNull()
        if (error == null) {
            state.update { it.copy(engine = EngineStatus.Ready) }
            return
        }
        val message = error.message ?: "Unknown error."
        if (message.startsWith("Could not open the model file")) {
            withContext(Dispatchers.IO) { provisioner.deleteInstalled() }
            state.update {
                it.copy(engine = EngineStatus.NeedsModel(0L, "The saved model looked damaged, so it was removed. Please download it again."))
            }
        } else {
            fail("Couldn't start the AI", message, canRetry = true)
        }
    }

    private fun fail(title: String, message: String, canRetry: Boolean) {
        state.update { it.copy(engine = EngineStatus.Failed(title, message, canRetry)) }
    }

    // ---- chatting ---------------------------------------------------------------------------------

    fun send(raw: String) {
        val text = raw.trim()
        val current = state.value
        if (text.isEmpty() || current.engine !is EngineStatus.Ready || current.generating) return
        speech.stop()
        val user = ChatMessage(nextId(), Role.USER, text)
        val reply = ChatMessage(nextId(), Role.ASSISTANT, "")
        state.update { it.copy(messages = it.messages + user + reply, generating = true, streamingId = reply.id) }
        persist()
        generate(reply.id)
    }

    fun regenerate() {
        val current = state.value
        if (current.engine !is EngineStatus.Ready || current.generating) return
        val messages = current.messages
        val lastAssistant = messages.indexOfLast { it.role == Role.ASSISTANT }
        if (lastAssistant < 0 || messages.none { it.role == Role.USER }) return
        speech.stop()
        val kept = messages.subList(0, lastAssistant)
        if (kept.none { it.role == Role.USER }) return
        val reply = ChatMessage(nextId(), Role.ASSISTANT, "")
        state.update { it.copy(messages = kept + reply, generating = true, streamingId = reply.id) }
        generate(reply.id)
    }

    fun stopGenerating() {
        activeStop?.set(true)
        engine.cancel()
    }

    fun newChat() {
        stopGenerating()
        generationJob?.cancel()
        speech.stop()
        state.update { it.copy(messages = emptyList(), generating = false, streamingId = null) }
        persist()
    }

    private fun publish(id: Long, text: String) {
        state.update { s -> s.copy(messages = s.messages.map { m -> if (m.id == id) m.copy(text = text) else m }) }
    }

    private fun generate(assistantId: Long) {
        val stop = AtomicBoolean(false)
        activeStop = stop
        generationJob = viewModelScope.launch {
            val history = state.value.messages
                .filter { it.id != assistantId && !it.isError && it.text.isNotBlank() }
                .map { PromptBuilder.Turn(if (it.role == Role.USER) "user" else "assistant", it.text) }

            val builder = StringBuilder()
            val decoder = Utf8StreamDecoder()
            var tokenCount = 0
            var lastFlush = 0L
            var failure: String? = null
            val startedAt = SystemClock.elapsedRealtime()

            try {
                withContext(engineDispatcher) {
                    val budget = ModelConfig.CONTEXT_SIZE - ModelConfig.MAX_NEW_TOKENS - 32
                    val trimmed = PromptBuilder.trim(history, budget) { engine.countTokens(it) }
                    val prompt = PromptBuilder.build(trimmed)
                    engine.generate(prompt, ModelConfig.MAX_NEW_TOKENS, listener = TokenListener { bytes ->
                        tokenCount++
                        val piece = decoder.push(bytes)
                        if (piece.isNotEmpty()) {
                            builder.append(piece)
                            val now = SystemClock.elapsedRealtime()
                            if (now - lastFlush >= FLUSH_INTERVAL_MS) {
                                lastFlush = now
                                publish(assistantId, builder.toString())
                            }
                        }
                        !stop.get()
                    })
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                failure = e.message ?: "Something went wrong while generating."
            }

            builder.append(decoder.finish())
            val finalText = builder.toString().trim()
            val seconds = (SystemClock.elapsedRealtime() - startedAt) / 1000.0
            val stats = if (tokenCount > 1 && seconds > 0.2) {
                String.format(Locale.US, "%.1f tok/s", tokenCount.toDouble() / seconds)
            } else null

            state.update { s ->
                val updated = when {
                    finalText.isEmpty() && failure != null ->
                        s.messages.map { if (it.id == assistantId) it.copy(text = "I couldn't finish that reply. $failure", isError = true) else it }
                    finalText.isEmpty() -> s.messages.filter { it.id != assistantId }
                    else -> s.messages.map { if (it.id == assistantId) it.copy(text = finalText, stats = stats) else it }
                }
                s.copy(messages = updated, generating = false, streamingId = null)
            }
            persist()

            if (finalText.isNotEmpty() && failure == null && !stop.get() && settings.value.autoRead) {
                speech.speak(assistantId, finalText, settings.value)
            }
        }
    }

    private fun persist() {
        val snapshot = state.value.messages
        viewModelScope.launch(Dispatchers.IO) { store.save(snapshot) }
    }

    // ---- speech and settings ----------------------------------------------------------------------

    fun toggleSpeak(message: ChatMessage) {
        if (speech.speakingId.value == message.id) speech.stop() else speech.speak(message.id, message.text, settings.value)
    }

    fun previewVoice(preview: AppSettings) = speech.preview(preview)

    fun stopSpeaking() = speech.stop()

    fun updateSettings(transform: (AppSettings) -> AppSettings) = settingsRepository.update(transform)

    override fun onCleared() {
        activeStop?.set(true)
        downloadJob?.cancel()
        engine.cancel()
        speech.shutdown()
        engineExecutor.execute { engine.release() }
        engineExecutor.shutdown()
        super.onCleared()
    }

    private companion object {
        const val FLUSH_INTERVAL_MS = 45L
    }
}
