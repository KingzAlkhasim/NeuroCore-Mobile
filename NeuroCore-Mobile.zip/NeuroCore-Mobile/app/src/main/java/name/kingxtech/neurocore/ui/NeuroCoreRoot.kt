package name.kingxtech.neurocore.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import name.kingxtech.neurocore.ChatViewModel
import name.kingxtech.neurocore.ui.chat.ChatScreen
import name.kingxtech.neurocore.ui.settings.SettingsScreen
import name.kingxtech.neurocore.ui.theme.NC

@Composable
fun NeuroCoreRoot(viewModel: ChatViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val voices by viewModel.speech.voices.collectAsStateWithLifecycle()
    val ttsReady by viewModel.speech.ready.collectAsStateWithLifecycle()
    val ttsUnavailable by viewModel.speech.unavailable.collectAsStateWithLifecycle()
    val speakingId by viewModel.speech.speakingId.collectAsStateWithLifecycle()

    var showSettings by rememberSaveable { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    fun copy(text: String, label: String) {
        clipboard.setText(AnnotatedString(text))
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            snackbar.showSnackbar(label)
        }
    }

    BackHandler(enabled = showSettings) { showSettings = false }
    LaunchedEffect(showSettings) {
        if (!showSettings) viewModel.stopSpeaking()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0C1020), NC.Night))),
    ) {
        // A soft violet glow behind the header gives the dark canvas some depth.
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .offset(y = (-170).dp)
                .size(460.dp)
                .background(Brush.radialGradient(listOf(NC.Violet.copy(alpha = 0.20f), Color.Transparent))),
        )

        AnimatedContent(
            targetState = showSettings,
            transitionSpec = {
                if (targetState) {
                    (slideInHorizontally(tween(280)) { it / 5 } + fadeIn(tween(280))) togetherWith fadeOut(tween(160))
                } else {
                    fadeIn(tween(240)) togetherWith (slideOutHorizontally(tween(260)) { it / 5 } + fadeOut(tween(200)))
                }
            },
            label = "screen",
        ) { settingsOpen ->
            if (settingsOpen) {
                SettingsScreen(
                    settings = settings,
                    voices = voices,
                    ttsReady = ttsReady,
                    ttsUnavailable = ttsUnavailable,
                    speakingId = speakingId,
                    onBack = { showSettings = false },
                    onUpdate = { transform -> viewModel.updateSettings(transform) },
                    onPreview = { preview -> viewModel.previewVoice(preview) },
                    onStopSpeaking = { viewModel.stopSpeaking() },
                )
            } else {
                ChatScreen(
                    state = state,
                    textScale = settings.textScale,
                    speakingId = speakingId,
                    onSend = viewModel::send,
                    onStop = viewModel::stopGenerating,
                    onRegenerate = viewModel::regenerate,
                    onNewChat = viewModel::newChat,
                    onOpenSettings = { showSettings = true },
                    onCopyMessage = { copy(it, "Reply copied") },
                    onCopyCode = { copy(it, "Code copied") },
                    onToggleSpeak = viewModel::toggleSpeak,
                    onRetryEngine = viewModel::retryEngine,
                    onDownload = viewModel::downloadModel,
                    onCancelDownload = viewModel::cancelDownload,
                )
            }
        }

        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 92.dp),
        ) { data ->
            Snackbar(
                snackbarData = data,
                containerColor = NC.SurfaceHigh,
                contentColor = NC.TextPrimary,
            )
        }
    }
}
