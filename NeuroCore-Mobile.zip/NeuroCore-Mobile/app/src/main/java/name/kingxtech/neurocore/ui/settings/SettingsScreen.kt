package name.kingxtech.neurocore.ui.settings

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import name.kingxtech.neurocore.data.AppSettings
import name.kingxtech.neurocore.engine.ModelConfig
import name.kingxtech.neurocore.tts.SpeechController
import name.kingxtech.neurocore.tts.VoiceOption
import name.kingxtech.neurocore.ui.components.MarkdownContent
import name.kingxtech.neurocore.ui.theme.NC
import java.util.Locale
import kotlin.math.roundToInt

private const val PREVIEW_MARKDOWN = "Answers look like this, with **bold**, *italic* and `inline code`.\n\n" +
    "- Clean lists\n- Rich Markdown\n\n" +
    "```kotlin\nfun greet(name: String) = \"Hello, \" + name\n```"

@Composable
fun SettingsScreen(
    settings: AppSettings,
    voices: List<VoiceOption>,
    ttsReady: Boolean,
    ttsUnavailable: Boolean,
    speakingId: Long?,
    onBack: () -> Unit,
    onUpdate: ((AppSettings) -> AppSettings) -> Unit,
    onPreview: (AppSettings) -> Unit,
    onStopSpeaking: () -> Unit,
) {
    val context = LocalContext.current
    var showVoiceSheet by remember { mutableStateOf(false) }
    val previewing = speakingId == SpeechController.PREVIEW_ID

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 6.dp, end = 12.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = NC.TextPrimary)
            }
            Text("Settings", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // ---- Voice
            SectionCard("Voice", Icons.Rounded.RecordVoiceOver) {
                if (ttsUnavailable) {
                    Notice(
                        "No text-to-speech engine found on this phone. Install or enable one in your system settings to hear replies read aloud.",
                        "Open speech settings",
                    ) { openSpeechSettings(context) }
                } else {
                    val selected = voices.firstOrNull { it.name == settings.voiceName }
                    VoiceRow(
                        title = when {
                            settings.voiceName == null -> "System default"
                            selected != null -> selected.title
                            else -> "System default"
                        },
                        subtitle = when {
                            settings.voiceName == null -> "Uses your phone's default voice"
                            selected != null -> selected.subtitle
                            else -> "Your chosen voice is no longer installed"
                        },
                        enabled = ttsReady,
                        onClick = { showVoiceSheet = true },
                    )
                    if (ttsReady && voices.isEmpty()) {
                        Text(
                            "No offline voices were found. You can download more in your system speech settings.",
                            color = NC.TextSecondary,
                            fontSize = 13.sp,
                            lineHeight = 19.sp,
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { if (previewing) onStopSpeaking() else onPreview(settings) },
                            enabled = ttsReady,
                            colors = ButtonDefaults.buttonColors(containerColor = NC.Violet, contentColor = Color.White),
                        ) {
                            Icon(if (previewing) Icons.Rounded.Stop else Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (previewing) "Stop" else "Test voice")
                        }
                        TextButton(onClick = { openSpeechSettings(context) }) {
                            Text("Manage voices", color = NC.Cyan)
                        }
                    }
                }
            }

            // ---- Speech
            SectionCard("Speech", Icons.Rounded.GraphicEq) {
                LabeledSlider(
                    label = "Speed",
                    valueText = String.format(Locale.US, "%.2f×", settings.speechRate),
                    value = settings.speechRate,
                    range = AppSettings.MIN_RATE..AppSettings.MAX_RATE,
                    isDefault = settings.speechRate == AppSettings.DEFAULT_RATE,
                    onReset = { onUpdate { it.copy(speechRate = AppSettings.DEFAULT_RATE) } },
                    onChange = { v -> onUpdate { it.copy(speechRate = snap(v, 20f)) } },
                )
                LabeledSlider(
                    label = "Pitch",
                    valueText = String.format(Locale.US, "%.2f", settings.pitch),
                    value = settings.pitch,
                    range = AppSettings.MIN_PITCH..AppSettings.MAX_PITCH,
                    isDefault = settings.pitch == AppSettings.DEFAULT_PITCH,
                    onReset = { onUpdate { it.copy(pitch = AppSettings.DEFAULT_PITCH) } },
                    onChange = { v -> onUpdate { it.copy(pitch = snap(v, 20f)) } },
                )
                HorizontalDivider(color = NC.Outline)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Read replies automatically", color = NC.TextPrimary, fontSize = 16.sp)
                        Text("Speak each answer as soon as it finishes", color = NC.TextSecondary, fontSize = 13.sp)
                    }
                    Switch(
                        checked = settings.autoRead,
                        onCheckedChange = { checked -> onUpdate { it.copy(autoRead = checked) } },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = NC.Violet,
                            uncheckedThumbColor = NC.TextSecondary,
                            uncheckedTrackColor = NC.SurfaceHigh,
                            uncheckedBorderColor = NC.Outline,
                        ),
                    )
                }
            }

            // ---- Appearance
            SectionCard("Reading", Icons.Rounded.TextFields) {
                LabeledSlider(
                    label = "Response text size",
                    valueText = "${(settings.textScale * 100).roundToInt()}%",
                    value = settings.textScale,
                    range = AppSettings.MIN_TEXT_SCALE..AppSettings.MAX_TEXT_SCALE,
                    isDefault = settings.textScale == AppSettings.DEFAULT_TEXT_SCALE,
                    onReset = { onUpdate { it.copy(textScale = AppSettings.DEFAULT_TEXT_SCALE) } },
                    onChange = { v -> onUpdate { it.copy(textScale = snap(v, 20f)) } },
                )
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = NC.Night,
                    border = BorderStroke(1.dp, NC.Outline),
                ) {
                    MarkdownContent(
                        markdown = PREVIEW_MARKDOWN,
                        textScale = settings.textScale,
                        onCopyCode = {},
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                    )
                }
            }

            // ---- About
            SectionCard("About", Icons.Rounded.Lock) {
                Text(
                    "${ModelConfig.DISPLAY_NAME} (${ModelConfig.QUANTIZATION}) runs entirely on this device through llama.cpp. " +
                        "The internet is used once, to download the model. Your conversations never leave your phone.",
                    color = NC.TextSecondary,
                    fontSize = 14.sp,
                    lineHeight = 21.sp,
                )
                Text("Version ${versionName(context)}", color = NC.TextTertiary, fontSize = 13.sp)
            }

            Spacer(Modifier.navigationBarsPadding().height(16.dp))
        }
    }

    if (showVoiceSheet) {
        VoiceSheet(
            voices = voices,
            selectedName = settings.voiceName,
            previewingId = speakingId,
            onSelect = { name -> onUpdate { it.copy(voiceName = name) } },
            onPreview = { name -> onPreview(settings.copy(voiceName = name)) },
            onDismiss = { showVoiceSheet = false },
        )
    }
}

private fun snap(value: Float, steps: Float): Float = (value * steps).roundToInt() / steps

private fun versionName(context: Context): String = try {
    context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "1.0"
} catch (e: Exception) {
    "1.0"
}

private fun openSpeechSettings(context: Context) {
    val candidates = listOf(
        Intent("com.android.settings.TTS_SETTINGS"),
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS),
        Intent(Settings.ACTION_SETTINGS),
    )
    for (intent in candidates) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return
        } catch (e: Exception) {
            // try the next fallback
        }
    }
}

@Composable
private fun SectionCard(title: String, icon: ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = NC.Surface,
        border = BorderStroke(1.dp, NC.Outline),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(34.dp).background(NC.SurfaceHigh, CircleShape), contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = NC.Cyan, modifier = Modifier.size(19.dp))
                }
                Spacer(Modifier.width(12.dp))
                Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            }
            content()
        }
    }
}

@Composable
private fun Notice(message: String, action: String, onAction: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(message, color = NC.TextSecondary, fontSize = 14.sp, lineHeight = 21.sp)
        OutlinedButton(onClick = onAction) { Text(action, color = NC.Cyan) }
    }
}

@Composable
private fun VoiceRow(title: String, subtitle: String, enabled: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(16.dp),
        color = NC.SurfaceHigh,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = NC.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text(subtitle, color = NC.TextSecondary, fontSize = 13.sp)
            }
            Icon(Icons.Rounded.ExpandMore, contentDescription = null, tint = NC.TextSecondary)
        }
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    isDefault: Boolean,
    onReset: () -> Unit,
    onChange: (Float) -> Unit,
) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = NC.TextPrimary, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Text(valueText, color = NC.Cyan, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            if (!isDefault) {
                TextButton(onClick = onReset) { Text("Reset", color = NC.TextSecondary, fontSize = 13.sp) }
            }
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = NC.Violet,
                inactiveTrackColor = NC.Outline,
            ),
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VoiceSheet(
    voices: List<VoiceOption>,
    selectedName: String?,
    previewingId: Long?,
    onSelect: (String?) -> Unit,
    onPreview: (String?) -> Unit,
    onDismiss: () -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = NC.Surface,
        contentColor = NC.TextPrimary,
    ) {
        Text(
            "Choose a voice",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
        )
        Text(
            "Only voices that work offline are shown.",
            color = NC.TextSecondary,
            fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 24.dp),
        )
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.navigationBarsPadding()) {
            item(key = "default") {
                VoiceChoice(
                    title = "System default",
                    subtitle = "Uses your phone's default voice",
                    selected = selectedName == null,
                    previewing = previewingId == SpeechController.PREVIEW_ID,
                    onSelect = { onSelect(null) },
                    onPreview = { onPreview(null) },
                )
            }
            items(voices, key = { it.name }) { voice ->
                VoiceChoice(
                    title = voice.title,
                    subtitle = voice.subtitle,
                    selected = selectedName == voice.name,
                    previewing = false,
                    onSelect = { onSelect(voice.name) },
                    onPreview = { onPreview(voice.name) },
                )
            }
            item(key = "end") { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun VoiceChoice(
    title: String,
    subtitle: String,
    selected: Boolean,
    previewing: Boolean,
    onSelect: () -> Unit,
    onPreview: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(role = Role.RadioButton, onClick = onSelect)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(
            selected = selected,
            onClick = null,
            colors = RadioButtonDefaults.colors(selectedColor = NC.Violet, unselectedColor = NC.TextTertiary),
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f).padding(vertical = 6.dp)) {
            Text(title, color = NC.TextPrimary, fontSize = 16.sp)
            Text(subtitle, color = NC.TextSecondary, fontSize = 13.sp)
        }
        IconButton(onClick = onPreview) {
            Icon(
                if (previewing) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                contentDescription = "Preview voice",
                tint = NC.Cyan,
            )
        }
    }
}
