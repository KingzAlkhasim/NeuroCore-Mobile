package name.kingxtech.neurocore.tts

import name.kingxtech.neurocore.markdown.Block
import name.kingxtech.neurocore.markdown.MarkdownParser
import name.kingxtech.neurocore.markdown.plainText

/** Turns Markdown into text that sounds natural when read aloud. */
object SpeechText {
    private val SYMBOLS = Regex("[\\p{So}\\p{Cs}\\uFE0F\\u200D]")
    private val MULTI_SPACE = Regex("[ \\t]{2,}")
    private val SPACE_BEFORE_PUNCT = Regex("\\s+([.,!?;:])")
    private val SENTENCE_END = Regex("(?<=[.!?。！？…])\\s+")

    fun toSpeakable(markdown: String): String {
        val lines = ArrayList<String>()
        var codeMentioned = false

        fun walk(blocks: List<Block>) {
            for (b in blocks) when (b) {
                is Block.Paragraph -> lines.add(b.inlines.plainText())
                is Block.Heading -> lines.add(b.inlines.plainText().trimEnd('.', ':') + ".")
                is Block.CodeBlock -> if (!codeMentioned) { lines.add("Code snippet omitted."); codeMentioned = true }
                is Block.Quote -> walk(b.blocks)
                is Block.ListBlock -> b.items.forEach { walk(it) }
                is Block.Table -> {
                    lines.add(b.header.joinToString(", ") { it.plainText() } + ".")
                    b.rows.forEach { row -> lines.add(row.joinToString(", ") { it.plainText() } + ".") }
                }
                Block.Rule -> Unit
            }
        }
        walk(MarkdownParser.parse(markdown))

        return lines
            .map { SYMBOLS.replace(it, "").replace(MULTI_SPACE, " ").replace(SPACE_BEFORE_PUNCT, "$1").trim() }
            .filter { it.isNotEmpty() }
            .joinToString("\n")
    }

    /** Splits text into pieces short enough to start speaking quickly and to stop cleanly. */
    fun chunk(text: String, maxLength: Int = 380): List<String> {
        val out = ArrayList<String>()
        val current = StringBuilder()

        fun flush() {
            if (current.isNotBlank()) out.add(current.toString().trim())
            current.setLength(0)
        }

        for (paragraph in text.split('\n')) {
            val p = paragraph.trim()
            if (p.isEmpty()) continue
            for (sentence in p.split(SENTENCE_END)) {
                var s = sentence.trim()
                if (s.isEmpty()) continue
                while (s.length > maxLength) {
                    val cut = s.lastIndexOf(' ', maxLength).let { if (it < maxLength / 2) maxLength else it }
                    if (current.isNotEmpty()) flush()
                    out.add(s.substring(0, cut).trim())
                    s = s.substring(cut).trim()
                }
                if (current.isNotEmpty() && current.length + 1 + s.length > maxLength) flush()
                if (current.isNotEmpty()) current.append(' ')
                current.append(s)
            }
            flush()
        }
        flush()
        return out
    }
}
