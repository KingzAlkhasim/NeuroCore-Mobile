package name.kingxtech.neurocore.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    /** Name of the chosen TextToSpeech voice, or null for the system default. */
    val voiceName: String? = null,
    val speechRate: Float = DEFAULT_RATE,
    val pitch: Float = DEFAULT_PITCH,
    val textScale: Float = DEFAULT_TEXT_SCALE,
    val autoRead: Boolean = false,
) {
    fun sanitized(): AppSettings = copy(
        speechRate = speechRate.coerceIn(MIN_RATE, MAX_RATE),
        pitch = pitch.coerceIn(MIN_PITCH, MAX_PITCH),
        textScale = textScale.coerceIn(MIN_TEXT_SCALE, MAX_TEXT_SCALE),
    )

    companion object {
        const val DEFAULT_RATE = 1.0f
        const val DEFAULT_PITCH = 1.0f
        const val DEFAULT_TEXT_SCALE = 1.0f
        const val MIN_RATE = 0.5f
        const val MAX_RATE = 2.0f
        const val MIN_PITCH = 0.5f
        const val MAX_PITCH = 2.0f
        const val MIN_TEXT_SCALE = 0.85f
        const val MAX_TEXT_SCALE = 1.6f
    }
}

/** Stores user preferences and exposes them as a flow so the UI and TTS react instantly. */
class SettingsRepository(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("neurocore_settings", Context.MODE_PRIVATE)
    private val state = MutableStateFlow(read())
    val settings: StateFlow<AppSettings> = state.asStateFlow()

    private fun read(): AppSettings = AppSettings(
        voiceName = prefs.getString(KEY_VOICE, null),
        speechRate = prefs.getFloat(KEY_RATE, AppSettings.DEFAULT_RATE),
        pitch = prefs.getFloat(KEY_PITCH, AppSettings.DEFAULT_PITCH),
        textScale = prefs.getFloat(KEY_TEXT_SCALE, AppSettings.DEFAULT_TEXT_SCALE),
        autoRead = prefs.getBoolean(KEY_AUTO_READ, false),
    ).sanitized()

    fun update(transform: (AppSettings) -> AppSettings) {
        val next = transform(state.value).sanitized()
        state.value = next
        prefs.edit()
            .putString(KEY_VOICE, next.voiceName)
            .putFloat(KEY_RATE, next.speechRate)
            .putFloat(KEY_PITCH, next.pitch)
            .putFloat(KEY_TEXT_SCALE, next.textScale)
            .putBoolean(KEY_AUTO_READ, next.autoRead)
            .apply()
    }

    private companion object {
        const val KEY_VOICE = "voice_name"
        const val KEY_RATE = "speech_rate"
        const val KEY_PITCH = "pitch"
        const val KEY_TEXT_SCALE = "text_scale"
        const val KEY_AUTO_READ = "auto_read"
    }
}
