package name.kingxtech.neurocore.engine

/** A downloadable model. All entries use the same ChatML format, so the prompt code is shared. */
data class ModelSpec(
    val id: String,
    val title: String,
    val tagline: String,
    val fileName: String,
    val url: String,
    val approxBytes: Long,
    /** Parameter count label shown in the UI, for example "1.5B". */
    val size: String,
) {
    /** Files smaller than this are treated as a failed or partial download. */
    val minValidBytes: Long get() = approxBytes * 8 / 10
}

object ModelCatalog {
    val lite = ModelSpec(
        id = "qwen2.5-0.5b-q4km",
        title = "Lite",
        tagline = "Fast and light. Best for older or budget phones.",
        fileName = "qwen2.5-0.5b-instruct-q4_k_m.gguf",
        url = "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf",
        approxBytes = 491_000_000L,
        size = "0.5B",
    )

    val standard = ModelSpec(
        id = "qwen2.5-1.5b-q4km",
        title = "Standard",
        tagline = "Smarter and more detailed. Needs a stronger phone.",
        fileName = "qwen2.5-1.5b-instruct-q4_k_m.gguf",
        url = "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf",
        approxBytes = 1_120_000_000L,
        size = "1.5B",
    )

    /** Ordered from smallest to largest. */
    val all: List<ModelSpec> = listOf(lite, standard)

    fun byId(id: String?): ModelSpec? = all.firstOrNull { it.id == id }
}

/** What we know about the phone, gathered before anything is downloaded. */
data class DeviceProfile(
    val totalRamBytes: Long,
    val is64BitArm: Boolean,
    val hasDotProduct: Boolean,
    val cores: Int,
) {
    fun summary(): String {
        val ram = String.format(java.util.Locale.US, "%.1f GB RAM", totalRamBytes / 1_000_000_000.0)
        val cpu = if (hasDotProduct) "modern processor" else "basic processor"
        return "$ram · $cores cores · $cpu"
    }
}

enum class Fit { RECOMMENDED, OK, SLOW, UNAVAILABLE }

data class ModelFit(val fit: Fit, val note: String)

object ModelRecommender {
    private const val LITE_MIN_RAM = 1_500_000_000L
    private const val STANDARD_MIN_RAM = 2_800_000_000L
    private const val STANDARD_COMFORTABLE_RAM = 3_400_000_000L
    private const val STANDARD_WITH_LITE_HEADROOM_RAM = 5_000_000_000L

    fun assess(spec: ModelSpec, d: DeviceProfile): ModelFit {
        if (!d.is64BitArm) return ModelFit(Fit.UNAVAILABLE, "This phone's processor isn't supported.")
        return when (spec.id) {
            ModelCatalog.lite.id -> when {
                d.totalRamBytes < LITE_MIN_RAM -> ModelFit(Fit.UNAVAILABLE, "Not enough memory on this phone.")
                d.totalRamBytes < STANDARD_WITH_LITE_HEADROOM_RAM || !d.hasDotProduct ->
                    ModelFit(Fit.RECOMMENDED, "Runs smoothly on your phone.")
                else -> ModelFit(Fit.OK, "Very fast, but your phone can handle Standard.")
            }
            ModelCatalog.standard.id -> when {
                d.totalRamBytes < STANDARD_MIN_RAM -> ModelFit(Fit.UNAVAILABLE, "Needs about 3 GB of memory.")
                !d.hasDotProduct -> ModelFit(Fit.SLOW, "Works, but will be slow on this processor.")
                d.totalRamBytes < STANDARD_COMFORTABLE_RAM -> ModelFit(Fit.OK, "Uses most of your memory. Close other apps first.")
                else -> ModelFit(Fit.RECOMMENDED, "Great quality and speed for your phone.")
            }
            else -> ModelFit(Fit.OK, "")
        }
    }

    /** The best choice for this phone: the biggest model that is comfortable, else the best that works. */
    fun recommended(d: DeviceProfile, specs: List<ModelSpec> = ModelCatalog.all): ModelSpec? {
        val bySizeDesc = specs.sortedByDescending { it.approxBytes }
        return bySizeDesc.firstOrNull { assess(it, d).fit == Fit.RECOMMENDED }
            ?: bySizeDesc.firstOrNull { assess(it, d).fit == Fit.OK }
            ?: bySizeDesc.firstOrNull { assess(it, d).fit == Fit.SLOW }
    }
}
