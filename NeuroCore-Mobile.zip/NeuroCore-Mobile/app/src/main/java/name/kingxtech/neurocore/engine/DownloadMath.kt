package name.kingxtech.neurocore.engine

import java.util.Locale

/** Small pure helpers for the model download (kept separate so they can be unit tested). */
object DownloadMath {
    /** Parses the total size out of a header like "bytes 100-999/1000". */
    fun parseContentRangeTotal(header: String?): Long? {
        if (header == null) return null
        val slash = header.lastIndexOf('/')
        if (slash < 0) return null
        return header.substring(slash + 1).trim().toLongOrNull()
    }

    fun formatBytes(bytes: Long): String = when {
        bytes >= 1_000_000_000L -> String.format(Locale.US, "%.2f GB", bytes / 1_000_000_000.0)
        bytes >= 1_000_000L -> String.format(Locale.US, "%d MB", bytes / 1_000_000L)
        else -> String.format(Locale.US, "%d KB", bytes / 1_000L)
    }

    /** Every GGUF model file starts with the ASCII bytes "GGUF". */
    fun looksLikeGguf(firstBytes: ByteArray): Boolean =
        firstBytes.size >= 4 && firstBytes[0] == 'G'.code.toByte() && firstBytes[1] == 'G'.code.toByte() &&
            firstBytes[2] == 'U'.code.toByte() && firstBytes[3] == 'F'.code.toByte()

    fun fraction(downloaded: Long, total: Long): Float =
        if (total <= 0L) 0f else (downloaded.toDouble() / total).toFloat().coerceIn(0f, 1f)
}
