package name.kingxtech.neurocore.markdown

enum class TokenType { Keyword, String, Number, Comment, Function, Type, Annotation, Tag, Attribute }

/** A highlighted span. Anything not covered by a token is plain text. */
data class Token(val start: Int, val end: Int, val type: TokenType)

/**
 * A small, dependency free tokenizer that covers the languages a chat assistant writes most often.
 * It is intentionally approximate: fast enough to re-run on every streamed update.
 */
object SyntaxHighlighter {

    private class Lang(
        val keywords: Set<String>,
        val lineComments: List<String> = listOf("//"),
        val blockComment: Pair<String, String>? = "/*" to "*/",
        val quotes: String = "\"'",
        val tripleQuotes: Boolean = false,
        val backtickStrings: Boolean = false,
        val preprocessor: Boolean = false,
        val shellVariables: Boolean = false,
        val annotations: Boolean = true,
        val caseInsensitive: Boolean = false,
        val keyColon: Boolean = false,
        val identExtra: String = "_$",
        val hexColors: Boolean = false,
    )

    private fun kw(words: String): Set<String> = words.split(' ', '\n').filter { it.isNotEmpty() }.toSet()

    private val KOTLIN = Lang(kw("""
        package import class interface object fun val var if else when for while do return break continue in is as
        null true false this super override open abstract sealed data enum companion private public protected internal
        suspend inline typealias try catch finally throw by init constructor lateinit const where out vararg
        """))
    private val JAVA = Lang(kw("""
        package import class interface enum extends implements new if else switch case default for while do return break
        continue null true false this super public private protected static final abstract void int long double float
        boolean char byte short try catch finally throw throws synchronized instanceof var record
        """))
    private val JS = Lang(kw("""
        import export from default class extends new if else switch case for while do return break continue null undefined
        true false this super function const let var async await try catch finally throw typeof instanceof of in yield
        interface type enum implements public private protected readonly static void delete
        """), backtickStrings = true)
    private val PYTHON = Lang(kw("""
        import from as def class if elif else for while return break continue pass None True False and or not in is
        lambda with try except finally raise yield global nonlocal async await assert del self
        """), lineComments = listOf("#"), blockComment = null, tripleQuotes = true)
    private val C_FAMILY = Lang(kw("""
        if else switch case default for while do return break continue goto struct class union enum typedef namespace
        using template typename public private protected virtual static const constexpr inline extern volatile
        void int long short char float double unsigned signed bool true false nullptr NULL new delete auto sizeof this
        include define ifdef ifndef endif
        """), preprocessor = true, annotations = false)
    private val CSHARP = Lang(kw("""
        using namespace class interface struct enum public private protected internal static readonly const new if else
        switch case default for foreach while do return break continue null true false this base void int long double
        float bool string var async await try catch finally throw override virtual abstract sealed in out ref
        """))
    private val GO = Lang(kw("""
        package import func var const type struct interface map chan if else switch case default for range return break
        continue go defer select nil true false fallthrough
        """), quotes = "\"'", backtickStrings = true, annotations = false)
    private val RUST = Lang(kw("""
        use mod pub fn let mut const static struct enum impl trait type where if else match for while loop return break
        continue true false self Self super crate as in ref move async await unsafe dyn
        """), quotes = "\"", annotations = false)
    private val SWIFT = Lang(kw("""
        import class struct enum protocol extension func var let if else switch case default for while repeat return break
        continue nil true false self super init deinit guard defer try catch throw throws async await public private
        internal static override in is as
        """))
    private val BASH = Lang(kw("""
        if then else elif fi for while until do done case esac in function return exit echo cd export local readonly
        source alias unset set shift true false
        """), lineComments = listOf("#"), blockComment = null, shellVariables = true, annotations = false)
    private val SQL = Lang(kw("""
        select from where insert into values update set delete create table alter drop index view join inner left right
        outer full cross on group by order having limit offset union all distinct as and or not null is in like between
        exists case when then else end primary key foreign references default unique count sum avg min max asc desc
        """), lineComments = listOf("--"), caseInsensitive = true, annotations = false)
    private val JSON = Lang(kw("true false null"), lineComments = emptyList(), blockComment = null,
        quotes = "\"", annotations = false, keyColon = true)
    private val YAML = Lang(kw("true false null yes no on off"), lineComments = listOf("#"), blockComment = null,
        annotations = false, keyColon = true, identExtra = "_-.")
    private val CSS = Lang(kw("important"), lineComments = emptyList(), keyColon = true, identExtra = "_-",
        annotations = false, hexColors = true)
    private val GENERIC = Lang(emptySet(), lineComments = emptyList(), blockComment = null, annotations = false)

    private val ALIASES: Map<String, String> = mapOf(
        "kotlin" to "kotlin", "kt" to "kotlin", "kts" to "kotlin",
        "java" to "java",
        "javascript" to "js", "js" to "js", "jsx" to "js", "ts" to "js", "tsx" to "js", "typescript" to "js", "node" to "js",
        "python" to "python", "py" to "python",
        "c" to "c", "cpp" to "c", "c++" to "c", "cc" to "c", "h" to "c", "hpp" to "c", "objc" to "c",
        "csharp" to "csharp", "cs" to "csharp", "c#" to "csharp",
        "go" to "go", "golang" to "go",
        "rust" to "rust", "rs" to "rust",
        "swift" to "swift",
        "bash" to "bash", "sh" to "bash", "shell" to "bash", "zsh" to "bash", "console" to "bash",
        "sql" to "sql", "mysql" to "sql", "postgresql" to "sql", "sqlite" to "sql",
        "json" to "json", "jsonc" to "json",
        "yaml" to "yaml", "yml" to "yaml", "toml" to "yaml",
        "css" to "css", "scss" to "css",
        "html" to "html", "xml" to "html", "svg" to "html", "xhtml" to "html",
    )

    private fun langFor(key: String): Lang = when (key) {
        "kotlin" -> KOTLIN; "java" -> JAVA; "js" -> JS; "python" -> PYTHON; "c" -> C_FAMILY
        "csharp" -> CSHARP; "go" -> GO; "rust" -> RUST; "swift" -> SWIFT; "bash" -> BASH
        "sql" -> SQL; "json" -> JSON; "yaml" -> YAML; "css" -> CSS
        else -> GENERIC
    }

    /** Returns the canonical language key, or null if unknown. */
    fun normalize(language: String?): String? =
        language?.trim()?.lowercase()?.removePrefix("language-")?.let { ALIASES[it] }

    fun highlight(code: String, language: String?): List<Token> {
        if (code.isEmpty() || code.length > 60_000) return emptyList()
        val key = normalize(language)
        return if (key == "html") tokenizeMarkup(code) else tokenize(code, langFor(key ?: ""))
    }

    private fun lineEnd(code: String, from: Int): Int {
        val e = code.indexOf('\n', from)
        return if (e < 0) code.length else e
    }

    private fun nextNonSpace(code: String, from: Int): Char {
        var i = from
        while (i < code.length && (code[i] == ' ' || code[i] == '\t')) i++
        return if (i < code.length) code[i] else '\u0000'
    }

    private fun tokenize(code: String, cfg: Lang): List<Token> {
        val out = ArrayList<Token>()
        val n = code.length
        var i = 0

        fun add(s: Int, e: Int, t: TokenType) { if (e > s) out.add(Token(s, e, t)) }

        fun isIdentChar(c: Char) = c.isLetterOrDigit() || cfg.identExtra.indexOf(c) >= 0

        while (i < n) {
            val c = code[i]

            val bc = cfg.blockComment
            if (bc != null && code.startsWith(bc.first, i)) {
                val end = code.indexOf(bc.second, i + bc.first.length)
                val e = if (end < 0) n else end + bc.second.length
                add(i, e, TokenType.Comment); i = e; continue
            }

            var commentEnd = -1
            for (p in cfg.lineComments) {
                if (code.startsWith(p, i)) { commentEnd = lineEnd(code, i); break }
            }
            if (commentEnd >= 0) { add(i, commentEnd, TokenType.Comment); i = commentEnd; continue }

            if (cfg.preprocessor && c == '#') {
                val lineStart = code.lastIndexOf('\n', i - 1) + 1
                if (code.substring(lineStart, i).isBlank()) {
                    val e = lineEnd(code, i); add(i, e, TokenType.Annotation); i = e; continue
                }
            }

            if (cfg.shellVariables && c == '$' && i + 1 < n && (code[i + 1].isLetter() || code[i + 1] == '_' || code[i + 1] == '{')) {
                var j = i + 1
                if (code[j] == '{') { val close = code.indexOf('}', j); j = if (close < 0) n else close + 1 }
                else while (j < n && (code[j].isLetterOrDigit() || code[j] == '_')) j++
                add(i, j, TokenType.Annotation); i = j; continue
            }

            if (cfg.tripleQuotes && (code.startsWith("\"\"\"", i) || code.startsWith("'''", i))) {
                val q = code.substring(i, i + 3)
                val end = code.indexOf(q, i + 3)
                val e = if (end < 0) n else end + 3
                add(i, e, TokenType.String); i = e; continue
            }

            if (cfg.quotes.indexOf(c) >= 0) {
                var j = i + 1
                while (j < n) {
                    val ch = code[j]
                    if (ch == '\\') { j += 2; continue }
                    if (ch == c) { j++; break }
                    if (ch == '\n') break
                    j++
                }
                val e = minOf(j, n)
                val type = if (cfg.keyColon && nextNonSpace(code, e) == ':') TokenType.Attribute else TokenType.String
                add(i, e, type); i = e; continue
            }

            if (cfg.backtickStrings && c == '`') {
                val end = code.indexOf('`', i + 1)
                val e = if (end < 0) n else end + 1
                add(i, e, TokenType.String); i = e; continue
            }

            if (cfg.hexColors && c == '#' && i + 1 < n && code[i + 1].isLetterOrDigit()) {
                var j = i + 1
                while (j < n && (code[j].isDigit() || code[j] in 'a'..'f' || code[j] in 'A'..'F')) j++
                if (j - i - 1 in 3..8) { add(i, j, TokenType.Number); i = j; continue }
            }

            if (c.isDigit() && (i == 0 || !(isIdentChar(code[i - 1])))) {
                var j = i
                if (c == '0' && i + 1 < n && (code[i + 1] == 'x' || code[i + 1] == 'X')) {
                    j = i + 2
                    while (j < n && (code[j].isDigit() || code[j] in 'a'..'f' || code[j] in 'A'..'F' || code[j] == '_')) j++
                } else {
                    while (j < n && (code[j].isDigit() || code[j] == '_')) j++
                    if (j + 1 < n && code[j] == '.' && code[j + 1].isDigit()) {
                        j++
                        while (j < n && (code[j].isDigit() || code[j] == '_')) j++
                    }
                    if (j < n && (code[j] == 'e' || code[j] == 'E') && j + 1 < n &&
                        (code[j + 1].isDigit() || ((code[j + 1] == '-' || code[j + 1] == '+') && j + 2 < n && code[j + 2].isDigit()))
                    ) {
                        j += 2
                        while (j < n && code[j].isDigit()) j++
                    }
                }
                while (j < n && (code[j].isLetter() || code[j] == '%')) j++
                add(i, j, TokenType.Number); i = j; continue
            }

            if (cfg.annotations && c == '@' && i + 1 < n && code[i + 1].isLetter()) {
                var j = i + 1
                while (j < n && (code[j].isLetterOrDigit() || code[j] == '_' || code[j] == '.')) j++
                add(i, j, TokenType.Annotation); i = j; continue
            }

            if (c.isLetter() || c == '_' || (c == '$' && !cfg.shellVariables)) {
                var j = i + 1
                while (j < n && isIdentChar(code[j])) j++
                val word = code.substring(i, j)
                val lookup = if (cfg.caseInsensitive) word.lowercase() else word
                val type: TokenType? = when {
                    lookup in cfg.keywords -> TokenType.Keyword
                    cfg.keyColon && nextNonSpace(code, j) == ':' && !code.startsWith("::", j) -> TokenType.Attribute
                    nextNonSpace(code, j) == '(' -> TokenType.Function
                    word.length > 1 && word[0].isUpperCase() -> TokenType.Type
                    else -> null
                }
                if (type != null) add(i, j, type)
                i = j; continue
            }

            i++
        }
        return out
    }

    private fun tokenizeMarkup(code: String): List<Token> {
        val out = ArrayList<Token>()
        val n = code.length
        var i = 0
        fun add(s: Int, e: Int, t: TokenType) { if (e > s) out.add(Token(s, e, t)) }

        while (i < n) {
            if (code.startsWith("<!--", i)) {
                val end = code.indexOf("-->", i + 4)
                val e = if (end < 0) n else end + 3
                add(i, e, TokenType.Comment); i = e; continue
            }
            val c = code[i]
            if (c == '<' && i + 1 < n && (code[i + 1].isLetter() || code[i + 1] == '/' || code[i + 1] == '!' || code[i + 1] == '?')) {
                var j = i + 1
                if (code[j] == '/') j++
                if (j < n && (code[j] == '!' || code[j] == '?')) j++
                while (j < n && (code[j].isLetterOrDigit() || code[j] == '-' || code[j] == ':' || code[j] == '.' || code[j] == '_')) j++
                add(i, j, TokenType.Tag)
                while (j < n && code[j] != '>') {
                    val ch = code[j]
                    if (ch == '"' || ch == '\'') {
                        val end = code.indexOf(ch, j + 1)
                        val e = if (end < 0) n else end + 1
                        add(j, e, TokenType.String); j = e
                    } else if (ch.isLetter()) {
                        var k = j
                        while (k < n && (code[k].isLetterOrDigit() || code[k] == '-' || code[k] == ':' || code[k] == '_' || code[k] == '@')) k++
                        add(j, k, TokenType.Attribute); j = k
                    } else j++
                }
                if (j < n) { add(j, j + 1, TokenType.Tag); j++ }
                i = j; continue
            }
            i++
        }
        return out
    }
}
