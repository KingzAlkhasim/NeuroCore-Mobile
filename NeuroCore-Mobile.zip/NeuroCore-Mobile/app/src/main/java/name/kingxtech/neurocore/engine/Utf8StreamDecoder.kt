package name.kingxtech.neurocore.engine

import java.nio.ByteBuffer
import java.nio.CharBuffer
import java.nio.charset.CodingErrorAction

/**
 * The model emits tokens, and one emoji or accented letter can be split across several of them.
 * This decoder holds back an incomplete trailing sequence until the next chunk completes it.
 */
class Utf8StreamDecoder {
    private val decoder = Charsets.UTF_8.newDecoder()
        .onMalformedInput(CodingErrorAction.REPLACE)
        .onUnmappableCharacter(CodingErrorAction.REPLACE)
    private var pending = ByteArray(0)

    fun push(bytes: ByteArray): String {
        val data = if (pending.isEmpty()) bytes else pending + bytes
        val input = ByteBuffer.wrap(data)
        val output = CharBuffer.allocate(data.size + 2)
        decoder.decode(input, output, false)
        pending = if (input.hasRemaining()) data.copyOfRange(input.position(), data.size) else ByteArray(0)
        output.flip()
        return output.toString()
    }

    /** Flushes a dangling partial sequence (only happens if generation was cut mid-character). */
    fun finish(): String {
        val dangling = pending.isNotEmpty()
        pending = ByteArray(0)
        return if (dangling) "\uFFFD" else ""
    }
}
