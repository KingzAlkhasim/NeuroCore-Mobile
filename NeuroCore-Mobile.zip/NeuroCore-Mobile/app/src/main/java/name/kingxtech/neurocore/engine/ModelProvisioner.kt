package name.kingxtech.neurocore.engine

import android.content.Context
import android.os.StatFs
import android.os.SystemClock
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

object ModelConfig {
    const val QUANTIZATION = "Q4_K_M"
    const val CONTEXT_SIZE = 4096
    const val MAX_NEW_TOKENS = 1536
}

sealed interface DownloadResult {
    data class Success(val file: File) : DownloadResult
    data class Failure(val message: String) : DownloadResult
}

/**
 * Finds the model on the device, or downloads it once. The download can be paused (cancelled) and
 * resumed: the partial file is kept and continued with an HTTP Range request.
 */
class ModelProvisioner(context: Context) {
    private val appContext = context.applicationContext

    private fun folder() = File(appContext.filesDir, "models")
    private fun installedFile(spec: ModelSpec) = File(folder(), spec.fileName)
    private fun partialFile(spec: ModelSpec) = File(folder(), spec.fileName + ".part")

    /** Developer shortcut: `adb push` the model here to skip the download. */
    private fun devFile(spec: ModelSpec) =
        File(File(appContext.getExternalFilesDir(null) ?: appContext.filesDir, "models"), spec.fileName)

    private fun isValid(f: File, spec: ModelSpec) = f.isFile && f.length() > spec.minValidBytes

    /** The usable model file, or null if it still has to be downloaded. */
    fun locate(spec: ModelSpec): File? {
        val installed = installedFile(spec)
        if (isValid(installed, spec)) return installed
        val dev = devFile(spec)
        if (isValid(dev, spec)) return dev
        return null
    }

    fun partialBytes(spec: ModelSpec): Long = partialFile(spec).let { if (it.isFile) it.length() else 0L }

    fun deleteInstalled(spec: ModelSpec) {
        installedFile(spec).delete()
    }

    private fun open(spec: ModelSpec, resumeFrom: Long): HttpURLConnection {
        val c = URL(spec.url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 30_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "NeuroCore-Mobile")
        if (resumeFrom > 0L) c.setRequestProperty("Range", "bytes=$resumeFrom-")
        return c
    }

    suspend fun download(spec: ModelSpec, onProgress: (downloaded: Long, total: Long) -> Unit): DownloadResult = withContext(Dispatchers.IO) {
        val ctx = currentCoroutineContext()
        var connection: HttpURLConnection? = null
        try {
            val dir = folder()
            if (!dir.exists() && !dir.mkdirs()) return@withContext DownloadResult.Failure("Could not create the model folder.")

            val part = partialFile(spec)
            var resumeFrom = if (part.isFile) part.length() else 0L

            val needed = (spec.approxBytes - resumeFrom).coerceAtLeast(0L) + SAFETY_MARGIN
            if (StatFs(dir.path).availableBytes < needed) {
                return@withContext DownloadResult.Failure(
                    "Not enough storage. NeuroCore needs about ${DownloadMath.formatBytes(needed)} of free space for its model.",
                )
            }

            var conn = open(spec, resumeFrom)
            connection = conn
            var code = conn.responseCode
            if (code == 416) {
                // The partial file no longer matches the server; start over.
                conn.disconnect()
                part.delete()
                resumeFrom = 0L
                conn = open(spec, 0L)
                connection = conn
                code = conn.responseCode
            }
            if (code != 200 && code != 206) {
                return@withContext DownloadResult.Failure("The download server answered with error $code. Please try again in a moment.")
            }
            if (code == 200 && resumeFrom > 0L) {
                part.delete()
                resumeFrom = 0L
            }

            val reported = if (code == 206) {
                DownloadMath.parseContentRangeTotal(conn.getHeaderField("Content-Range"))
                    ?: conn.contentLengthLong.let { if (it > 0L) resumeFrom + it else -1L }
            } else {
                conn.contentLengthLong
            }
            val total = if (reported > 0L) reported else spec.approxBytes

            conn.inputStream.use { input ->
                FileOutputStream(part, resumeFrom > 0L).use { out ->
                    val buffer = ByteArray(256 * 1024)
                    var downloaded = resumeFrom
                    var lastReport = 0L
                    onProgress(downloaded, total)
                    while (true) {
                        ctx.ensureActive()
                        val n = input.read(buffer)
                        if (n < 0) break
                        out.write(buffer, 0, n)
                        downloaded += n
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastReport >= 250L) {
                            lastReport = now
                            onProgress(downloaded, total)
                        }
                    }
                    out.flush()
                }
            }

            if (reported > 0L && part.length() < reported) {
                return@withContext DownloadResult.Failure("The connection dropped before the download finished. Tap Resume to continue.")
            }
            if (part.length() <= spec.minValidBytes) {
                part.delete()
                return@withContext DownloadResult.Failure("The downloaded file was too small to be the model. Please try again.")
            }
            val head = ByteArray(4)
            part.inputStream().use { it.read(head) }
            if (!DownloadMath.looksLikeGguf(head)) {
                part.delete()
                return@withContext DownloadResult.Failure("The downloaded file was not a valid model. Please try again.")
            }

            val target = installedFile(spec)
            if (target.exists()) target.delete()
            if (!part.renameTo(target)) {
                return@withContext DownloadResult.Failure("Could not finish installing the model.")
            }
            onProgress(total, total)
            DownloadResult.Success(target)
        } catch (e: CancellationException) {
            throw e
        } catch (e: UnknownHostException) {
            DownloadResult.Failure("No internet connection. Connect to Wi-Fi and try again. Your progress is saved.")
        } catch (e: ConnectException) {
            DownloadResult.Failure("Couldn't reach the download server. Check your connection and try again.")
        } catch (e: SocketTimeoutException) {
            DownloadResult.Failure("The connection timed out. Tap Resume to continue where you left off.")
        } catch (e: IOException) {
            DownloadResult.Failure("The download was interrupted (${e.message ?: "network error"}). Tap Resume to continue.")
        } catch (e: Exception) {
            DownloadResult.Failure(e.message ?: "The download failed.")
        } finally {
            try {
                connection?.disconnect()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    private companion object {
        const val SAFETY_MARGIN = 150L * 1024 * 1024
    }
}
