package name.kingxtech.neurocore.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import name.kingxtech.neurocore.data.AppSettings
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

/** A voice the user can pick. Only voices that work without a network connection are listed. */
data class VoiceOption(
    val name: String,
    val title: String,
    val subtitle: String,
    val language: String,
    val quality: Int,
)

/** Wraps Android's TextToSpeech: offline voices, speed, pitch and chunked playback with clean stop. */
class SpeechController(context: Context) {
    private val appContext = context.applicationContext
    private var tts: TextToSpeech? = null
    private var voiceMap: Map<String, Voice> = emptyMap()

    private val readyState = MutableStateFlow(false)
    private val failedState = MutableStateFlow(false)
    private val voicesState = MutableStateFlow<List<VoiceOption>>(emptyList())
    private val speakingState = MutableStateFlow<Long?>(null)

    val ready: StateFlow<Boolean> = readyState.asStateFlow()
    val unavailable: StateFlow<Boolean> = failedState.asStateFlow()
    val voices: StateFlow<List<VoiceOption>> = voicesState.asStateFlow()

    /** Id of the message being read aloud, [PREVIEW_ID] for a voice preview, or null when silent. */
    val speakingId: StateFlow<Long?> = speakingState.asStateFlow()

    private val tokens = AtomicLong(0)

    @Volatile
    private var lastUtteranceId: String? = null

    init {
        tts = TextToSpeech(appContext) { status -> onInit(status) }
    }

    private fun onInit(status: Int) {
        val engine = tts
        if (status != TextToSpeech.SUCCESS || engine == null) {
            failedState.value = true
            return
        }
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { finishIfLast(utteranceId) }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { finishIfLast(utteranceId) }
            override fun onError(utteranceId: String?, errorCode: Int) { finishIfLast(utteranceId) }
        })
        val result = engine.setLanguage(Locale.getDefault())
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale.US)
        }
        loadVoices(engine)
        readyState.value = true
    }

    private fun loadVoices(engine: TextToSpeech) {
        val all: Set<Voice> = try {
            engine.voices ?: emptySet()
        } catch (e: Exception) {
            emptySet()
        }
        val usable = all.filter {
            !it.isNetworkConnectionRequired && !it.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
        }
        voiceMap = usable.associateBy { it.name }

        val deviceLanguage = Locale.getDefault().language
        val sorted = usable.sortedWith(
            compareBy<Voice>({ it.locale.language != deviceLanguage }, { it.locale.displayName }, { -it.quality }, { it.name }),
        )
        val perLocale = HashMap<String, Int>()
        voicesState.value = sorted.map { v ->
            val tag = v.locale.toLanguageTag()
            val index = (perLocale[tag] ?: 0) + 1
            perLocale[tag] = index
            VoiceOption(
                name = v.name,
                title = "${v.locale.displayName} · Voice $index",
                subtitle = qualityLabel(v.quality),
                language = v.locale.language,
                quality = v.quality,
            )
        }
    }

    private fun qualityLabel(quality: Int): String = when {
        quality >= Voice.QUALITY_VERY_HIGH -> "Very high quality"
        quality >= Voice.QUALITY_HIGH -> "High quality"
        quality >= Voice.QUALITY_NORMAL -> "Standard quality"
        else -> "Compact"
    }

    private fun finishIfLast(utteranceId: String?) {
        if (utteranceId != null && utteranceId == lastUtteranceId) {
            lastUtteranceId = null
            speakingState.value = null
        }
    }

    private fun apply(engine: TextToSpeech, settings: AppSettings) {
        engine.setSpeechRate(settings.speechRate)
        engine.setPitch(settings.pitch)
        val chosen = settings.voiceName?.let { voiceMap[it] }
        try {
            if (chosen != null) {
                engine.setVoice(chosen)
            } else {
                engine.getDefaultVoice()?.let { engine.setVoice(it) }
            }
        } catch (e: Exception) {
            // Some engines reject voice changes; fall back to whatever is active.
        }
    }

    /** Reads Markdown [markdown] aloud. Replaces anything currently being spoken. */
    fun speak(id: Long, markdown: String, settings: AppSettings) {
        val engine = tts ?: return
        if (!readyState.value) return
        val chunks = SpeechText.chunk(SpeechText.toSpeakable(markdown))
        if (chunks.isEmpty()) return

        apply(engine, settings)
        val token = tokens.incrementAndGet()
        val lastId = "nc-$token-${chunks.size - 1}"
        lastUtteranceId = lastId
        speakingState.value = id
        var failed = false
        chunks.forEachIndexed { index, chunk ->
            val mode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
            if (engine.speak(chunk, mode, null, "nc-$token-$index") == TextToSpeech.ERROR) failed = true
        }
        if (failed) stop()
    }

    fun preview(settings: AppSettings) {
        speak(PREVIEW_ID, "Hi, I'm NeuroCore. This is how I will sound when I read your answers aloud.", settings)
    }

    fun stop() {
        lastUtteranceId = null
        speakingState.value = null
        try {
            tts?.stop()
        } catch (e: Exception) {
            // ignore
        }
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
    }

    companion object {
        const val PREVIEW_ID = -1L
    }
}
