package name.kingxtech.neurocore.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Saves the current conversation on the device so it survives app restarts. Nothing leaves the phone. */
class ChatStore(context: Context) {
    private val file = File(context.applicationContext.filesDir, "conversation.json")

    fun load(): List<ChatMessage> = try {
        if (!file.exists()) {
            emptyList()
        } else {
            val array = JSONArray(file.readText())
            val result = ArrayList<ChatMessage>(array.length())
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                val text = o.optString("text", "")
                if (text.isEmpty()) continue
                result.add(
                    ChatMessage(
                        id = o.optLong("id", System.nanoTime()),
                        role = if (o.optString("role") == "user") Role.USER else Role.ASSISTANT,
                        text = text,
                        stats = if (o.has("stats")) o.optString("stats") else null,
                        isError = o.optBoolean("isError", false),
                    ),
                )
            }
            result
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(messages: List<ChatMessage>) {
        try {
            val array = JSONArray()
            for (m in messages.takeLast(MAX_STORED)) {
                if (m.text.isEmpty()) continue
                val o = JSONObject()
                o.put("id", m.id)
                o.put("role", if (m.role == Role.USER) "user" else "assistant")
                o.put("text", m.text)
                if (m.stats != null) o.put("stats", m.stats)
                if (m.isError) o.put("isError", true)
                array.put(o)
            }
            val tmp = File(file.parentFile, "conversation.json.tmp")
            tmp.writeText(array.toString())
            if (!tmp.renameTo(file)) {
                file.writeText(array.toString())
                tmp.delete()
            }
        } catch (e: Exception) {
            // Persistence is best effort; a failed save must never crash the chat.
        }
    }

    private companion object {
        const val MAX_STORED = 200
    }
}
