package name.kingxtech.neurocore.data

enum class Role { USER, ASSISTANT }

data class ChatMessage(
    val id: Long,
    val role: Role,
    val text: String,
    /** Small caption shown under finished replies, for example "14.2 tok/s". */
    val stats: String? = null,
    val isError: Boolean = false,
)
