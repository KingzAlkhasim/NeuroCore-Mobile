// JNI bridge between NeuroCore (Kotlin) and llama.cpp.
//
// Design notes
//  * All text crosses the boundary as UTF-8 byte arrays, never jstring. JNI's "modified UTF-8" cannot
//    represent emoji, and tokens can end mid-character, so raw bytes are the only safe format.
//  * The KV cache is kept between turns. Each new prompt is compared with the tokens already in the
//    cache and only the new suffix is decoded, so follow-up messages start almost instantly.
//  * Every entry point is wrapped in try/catch so a C++ exception can never take the app down.
#include <jni.h>

#include <atomic>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

#ifdef __ANDROID__
#include <android/log.h>
#define NC_LOG(...) __android_log_print(ANDROID_LOG_INFO, "NeuroCore", __VA_ARGS__)
#else
#include <cstdio>
#define NC_LOG(...) (std::fprintf(stderr, __VA_ARGS__), std::fprintf(stderr, "\n"))
#endif

namespace {

std::string g_last_error;
std::atomic<bool> g_cancel{false};

void set_error(const std::string & msg) {
    g_last_error = msg;
    NC_LOG("error: %s", msg.c_str());
}

jstring to_jstring_ascii(JNIEnv * env, const std::string & s) {
    // Error messages are built from ASCII literals and file paths; replace anything else defensively.
    std::string safe;
    safe.reserve(s.size());
    for (unsigned char c : s) safe.push_back(c < 0x80 ? static_cast<char>(c) : '?');
    return env->NewStringUTF(safe.c_str());
}

} // namespace

#ifdef NEUROCORE_HAS_LLAMA

#include "llama.h"

namespace {

struct Engine {
    llama_model * model = nullptr;
    llama_context * ctx = nullptr;
    const llama_vocab * vocab = nullptr;
    std::vector<llama_token> cached;  // tokens currently held in the KV cache (sequence 0)
    int n_ctx = 0;
    int n_batch = 512;
};

void log_callback(ggml_log_level level, const char * text, void *) {
    if (level >= GGML_LOG_LEVEL_WARN) NC_LOG("%s", text);
}

std::vector<llama_token> tokenize(const llama_vocab * vocab, const std::string & text, bool add_special, bool parse_special) {
    int n = -llama_tokenize(vocab, text.c_str(), static_cast<int32_t>(text.size()), nullptr, 0, add_special, parse_special);
    if (n <= 0) return {};
    std::vector<llama_token> tokens(static_cast<size_t>(n));
    int r = llama_tokenize(vocab, text.c_str(), static_cast<int32_t>(text.size()), tokens.data(),
                           static_cast<int32_t>(tokens.size()), add_special, parse_special);
    if (r < 0) return {};
    tokens.resize(static_cast<size_t>(r));
    return tokens;
}

std::string bytes_to_string(JNIEnv * env, jbyteArray arr) {
    if (arr == nullptr) return {};
    jsize len = env->GetArrayLength(arr);
    std::string out(static_cast<size_t>(len), '\0');
    if (len > 0) env->GetByteArrayRegion(arr, 0, len, reinterpret_cast<jbyte *>(&out[0]));
    return out;
}

// Decodes `tokens` in n_batch sized chunks. Returns false on failure or cancellation.
bool decode_tokens(Engine * e, std::vector<llama_token> & tokens, size_t from, bool track) {
    size_t pos = from;
    while (pos < tokens.size()) {
        if (g_cancel.load()) return false;
        size_t n = std::min(static_cast<size_t>(e->n_batch), tokens.size() - pos);
        llama_batch batch = llama_batch_get_one(tokens.data() + pos, static_cast<int32_t>(n));
        if (llama_decode(e->ctx, batch) != 0) {
            set_error("llama_decode failed while reading the prompt");
            return false;
        }
        if (track) e->cached.insert(e->cached.end(), tokens.begin() + pos, tokens.begin() + pos + n);
        pos += n;
    }
    return true;
}

} // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_name_kingxtech_neurocore_engine_LlamaNative_load(JNIEnv * env, jobject, jstring jpath, jint n_ctx, jint n_threads) {
    try {
        static bool backend_ready = false;
        if (!backend_ready) {
            llama_log_set(log_callback, nullptr);
            llama_backend_init();
            backend_ready = true;
        }
        const char * path = env->GetStringUTFChars(jpath, nullptr);
        std::string model_path = path ? path : "";
        if (path) env->ReleaseStringUTFChars(jpath, path);

        llama_model_params mp = llama_model_default_params();
        mp.n_gpu_layers = 0;
        mp.use_mmap = true;
        llama_model * model = llama_model_load_from_file(model_path.c_str(), mp);
        if (!model) {
            set_error("Could not open the model file. It may be missing or damaged.");
            return 0;
        }

        llama_context_params cp = llama_context_default_params();
        cp.n_ctx = static_cast<uint32_t>(n_ctx);
        cp.n_batch = 512;
        cp.n_ubatch = 512;
        cp.n_threads = n_threads;
        cp.n_threads_batch = n_threads;
        llama_context * ctx = llama_init_from_model(model, cp);
        if (!ctx) {
            llama_model_free(model);
            set_error("Not enough free memory to start the model. Close other apps and try again.");
            return 0;
        }

        auto * e = new Engine();
        e->model = model;
        e->ctx = ctx;
        e->vocab = llama_model_get_vocab(model);
        e->n_ctx = static_cast<int>(llama_n_ctx(ctx));
        e->n_batch = static_cast<int>(cp.n_batch);
        return reinterpret_cast<jlong>(e);
    } catch (const std::exception & ex) {
        set_error(std::string("Native load failed: ") + ex.what());
    } catch (...) {
        set_error("Native load failed with an unknown error");
    }
    return 0;
}

JNIEXPORT jstring JNICALL
Java_name_kingxtech_neurocore_engine_LlamaNative_lastError(JNIEnv * env, jobject) {
    return to_jstring_ascii(env, g_last_error);
}

JNIEXPORT jint JNICALL
Java_name_kingxtech_neurocore_engine_LlamaNative_tokenCount(JNIEnv * env, jobject, jlong handle, jbyteArray text) {
    try {
        auto * e = reinterpret_cast<Engine *>(handle);
        if (!e) return -1;
        std::string s = bytes_to_string(env, text);
        return static_cast<jint>(tokenize(e->vocab, s, false, true).size());
    } catch (...) {
        return -1;
    }
}

JNIEXPORT void JNICALL
Java_name_kingxtech_neurocore_engine_LlamaNative_cancel(JNIEnv *, jobject) {
    g_cancel.store(true);
}

JNIEXPORT void JNICALL
Java_name_kingxtech_neurocore_engine_LlamaNative_resetCache(JNIEnv *, jobject, jlong handle) {
    auto * e = reinterpret_cast<Engine *>(handle);
    if (!e) return;
    llama_kv_self_clear(e->ctx);
    e->cached.clear();
}

JNIEXPORT jint JNICALL
Java_name_kingxtech_neurocore_engine_LlamaNative_generate(JNIEnv * env, jobject, jlong handle, jbyteArray jprompt,
                                                          jint max_new, jfloat temperature, jfloat top_p, jint top_k,
                                                          jfloat repeat_penalty, jint seed, jobject listener) {
    auto * e = reinterpret_cast<Engine *>(handle);
    if (!e) { set_error("Model is not loaded"); return -1; }
    g_cancel.store(false);

    llama_sampler * sampler = nullptr;
    try {
        jclass listener_cls = env->GetObjectClass(listener);
        jmethodID on_token = env->GetMethodID(listener_cls, "onToken", "([B)Z");
        if (!on_token) { set_error("TokenListener.onToken not found"); return -1; }

        std::string prompt = bytes_to_string(env, jprompt);
        std::vector<llama_token> tokens = tokenize(e->vocab, prompt, false, true);
        if (tokens.empty()) { set_error("The prompt could not be tokenized"); return -1; }
        if (static_cast<int>(tokens.size()) >= e->n_ctx - 8) {
            set_error("The conversation is too long for the context window");
            return -1;
        }

        // Re-use the part of the KV cache that matches the start of the new prompt.
        size_t common = 0;
        const size_t limit = std::min(e->cached.size(), tokens.size());
        while (common < limit && e->cached[common] == tokens[common]) common++;
        if (common == tokens.size()) common--;  // always decode at least one token so logits exist
        if (common == 0) {
            llama_kv_self_clear(e->ctx);
            e->cached.clear();
        } else if (!llama_kv_self_seq_rm(e->ctx, 0, static_cast<llama_pos>(common), -1)) {
            llama_kv_self_clear(e->ctx);
            e->cached.clear();
            common = 0;
        } else {
            e->cached.resize(common);
        }

        if (!decode_tokens(e, tokens, common, true)) {
            // Cancelled during prompt processing is not an error; the cache is simply left partial.
            if (g_cancel.load()) return 0;
            llama_kv_self_clear(e->ctx);
            e->cached.clear();
            return -1;
        }

        llama_sampler_chain_params sp = llama_sampler_chain_default_params();
        sampler = llama_sampler_chain_init(sp);
        llama_sampler_chain_add(sampler, llama_sampler_init_penalties(64, repeat_penalty, 0.0f, 0.0f));
        llama_sampler_chain_add(sampler, llama_sampler_init_top_k(top_k));
        llama_sampler_chain_add(sampler, llama_sampler_init_top_p(top_p, 1));
        llama_sampler_chain_add(sampler, llama_sampler_init_temp(temperature));
        llama_sampler_chain_add(sampler, llama_sampler_init_dist(static_cast<uint32_t>(seed)));

        int generated = 0;
        char small[256];
        for (int i = 0; i < max_new; i++) {
            if (g_cancel.load()) break;
            if (static_cast<int>(e->cached.size()) >= e->n_ctx - 1) break;

            llama_token id = llama_sampler_sample(sampler, e->ctx, -1);
            if (llama_vocab_is_eog(e->vocab, id)) break;

            int n = llama_token_to_piece(e->vocab, id, small, sizeof(small), 0, false);
            std::vector<char> big;
            const char * piece = small;
            if (n < 0) {
                big.resize(static_cast<size_t>(-n));
                n = llama_token_to_piece(e->vocab, id, big.data(), static_cast<int32_t>(big.size()), 0, false);
                piece = big.data();
            }
            if (n < 0) n = 0;

            jbyteArray arr = env->NewByteArray(n);
            if (arr == nullptr) { set_error("Out of memory"); break; }
            if (n > 0) env->SetByteArrayRegion(arr, 0, n, reinterpret_cast<const jbyte *>(piece));
            jboolean keep_going = env->CallBooleanMethod(listener, on_token, arr);
            env->DeleteLocalRef(arr);
            if (env->ExceptionCheck()) { env->ExceptionClear(); break; }
            generated++;
            if (!keep_going) break;

            llama_batch batch = llama_batch_get_one(&id, 1);
            if (llama_decode(e->ctx, batch) != 0) { set_error("llama_decode failed while generating"); break; }
            e->cached.push_back(id);
        }

        llama_sampler_free(sampler);
        return generated;
    } catch (const std::exception & ex) {
        set_error(std::string("Generation failed: ") + ex.what());
    } catch (...) {
        set_error("Generation failed with an unknown error");
    }
    if (sampler) llama_sampler_free(sampler);
    return -1;
}

JNIEXPORT void JNICALL
Java_name_kingxtech_neurocore_engine_LlamaNative_release(JNIEnv *, jobject, jlong handle) {
    auto * e = reinterpret_cast<Engine *>(handle);
    if (!e) return;
    if (e->ctx) llama_free(e->ctx);
    if (e->model) llama_model_free(e->model);
    delete e;
}

} // extern "C"

#else  // ---- stub: llama.cpp was not fetched --------------------------------------------------------------

extern "C" {

JNIEXPORT jlong JNICALL
Java_name_kingxtech_neurocore_engine_LlamaNative_load(JNIEnv *, jobject, jstring, jint, jint) {
    set_error("The AI engine is not installed in this build. Run scripts/setup.sh, then rebuild.");
    return 0;
}
JNIEXPORT jstring JNICALL
Java_name_kingxtech_neurocore_engine_LlamaNative_lastError(JNIEnv * env, jobject) { return to_jstring_ascii(env, g_last_error); }
JNIEXPORT jint JNICALL
Java_name_kingxtech_neurocore_engine_LlamaNative_tokenCount(JNIEnv *, jobject, jlong, jbyteArray) { return -1; }
JNIEXPORT void JNICALL
Java_name_kingxtech_neurocore_engine_LlamaNative_cancel(JNIEnv *, jobject) { g_cancel.store(true); }
JNIEXPORT void JNICALL
Java_name_kingxtech_neurocore_engine_LlamaNative_resetCache(JNIEnv *, jobject, jlong) {}
JNIEXPORT jint JNICALL
Java_name_kingxtech_neurocore_engine_LlamaNative_generate(JNIEnv *, jobject, jlong, jbyteArray, jint, jfloat, jfloat, jint, jfloat, jint, jobject) { return -1; }
JNIEXPORT void JNICALL
Java_name_kingxtech_neurocore_engine_LlamaNative_release(JNIEnv *, jobject, jlong) {}

} // extern "C"

#endif
