# JNI looks these up by name.
-keep class name.kingxtech.neurocore.engine.LlamaNative { *; }
-keep interface name.kingxtech.neurocore.engine.TokenListener { *; }
