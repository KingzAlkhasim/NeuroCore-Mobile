#!/usr/bin/env bash
# One-time setup: fetches llama.cpp (pinned). The AI model is downloaded by the app itself on first launch.
#   ./scripts/setup.sh           # llama.cpp only
#   ./scripts/setup.sh --model   # also downloads the model to ./qwen2.5-1.5b-instruct-q4_k_m.gguf (for `adb push` dev testing)
set -euo pipefail

LLAMA_TAG="b5400"
MODEL_FILE="qwen2.5-1.5b-instruct-q4_k_m.gguf"
MODEL_URL="https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/${MODEL_FILE}"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LLAMA_DIR="$ROOT/app/src/main/cpp/llama.cpp"

if [ ! -f "$LLAMA_DIR/CMakeLists.txt" ]; then
  echo "==> Cloning llama.cpp $LLAMA_TAG"
  git clone --depth 1 --branch "$LLAMA_TAG" https://github.com/ggml-org/llama.cpp "$LLAMA_DIR"
else
  echo "==> llama.cpp already present"
fi

if [ "${1:-}" = "--model" ]; then
  echo "==> Downloading $MODEL_FILE (about 1.1 GB)"
  curl -L --fail --retry 5 --retry-delay 5 -C - -o "$ROOT/$MODEL_FILE" "$MODEL_URL"
  echo "Push it with: adb push $MODEL_FILE /sdcard/Android/data/name.kingxtech.neurocore/files/models/"
fi
echo "==> Done. Build with: ./gradlew assembleDebug"
