# NeuroCore Mobile

**A private, offline AI assistant for Android, built by KingxTech.** Install it, open it, chat. No account, no internet, no data leaving the phone.

| Area | Decision |
| --- | --- |
| Language | Kotlin |
| UI | Jetpack Compose (dark, violet/cyan) |
| Models | Qwen2.5 Q4_K_M, picked in-app: **Lite** (0.5B) or **Standard** (1.5B). The app checks the phone and recommends one. Downloaded once, resumable |
| Runtime | llama.cpp (pinned to `b5400`), called through JNI |
| Markdown | Own renderer: headings, lists, quotes, tables, links, code |
| Code | Syntax highlighting for Kotlin, Java, JS/TS, Python, C/C++, C#, Go, Rust, Swift, Bash, SQL, JSON, YAML, CSS, HTML |
| Speech | Android `TextToSpeech`, offline voices only |
| Network | Only for the one-time model download. Chat and speech never use the network |

## Features

- Streaming replies with a stop button, regenerate, copy, and read-aloud per message
- Fast follow-ups: the KV cache is reused between turns, so only new text is processed
- Conversation saved on-device and restored on launch
- **Phone check before any download:** RAM and CPU are read first, the best model is recommended, and unsupported phones are told up front
- **Custom instructions:** your own standing instructions for the assistant, saved on the device, work offline
- **Settings:** choose the TTS voice (with preview), speech speed, pitch, response text size (with live preview), and auto-read

## Build without a PC (GitHub Actions)

1. Put `NeuroCore-Mobile.zip` in the repo root (GitHub web, **Add file > Upload files**) and commit to `main`.
2. Open the **Actions** tab and wait for "Build NeuroCore APK" to finish (about 10 to 15 minutes).
3. Open the **Releases** page on your phone and tap `NeuroCore-debug.apk` to install it.

If the build fails, open the failed step in the Actions tab and copy the red error lines.

## Build without a PC (Codemagic, if GitHub Actions is unavailable)

1. Upload `NeuroCore-Mobile.zip` and `codemagic.yaml` to the repo root.
2. Sign in at codemagic.io, add the repo, choose the `codemagic.yaml` configuration and start a build.
3. When it finishes, open the build page on your phone and download the APK from **Artifacts**.

## Build locally

Requires Android Studio (or JDK 17 + Android SDK), NDK `27.0.12077973` and CMake `3.22.1`.

```bash
./scripts/setup.sh        # fetches llama.cpp b5400
./gradlew assembleDebug   # app/build/outputs/apk/debug/app-debug.apk
./gradlew testDebugUnitTest
```

Skip the download while developing: `./scripts/setup.sh --model`, then
`adb push qwen2.5-1.5b-instruct-q4_k_m.gguf /sdcard/Android/data/name.kingxtech.neurocore/files/models/`.

Without llama.cpp fetched the project still builds, using a stub engine that shows a clear message in-app.

## How first launch works

The APK is small. On first launch NeuroCore asks to download the model (about 1.1 GB, Wi-Fi recommended) with a progress bar. Pausing or losing the connection keeps the partial file and the download resumes where it stopped. Once installed, the app never needs the internet again. Plan for about 1.3 GB of free storage.

## Requirements and limits

- 64-bit ARM phone, Android 8.0+ (built for plain ARMv8-A, so older Cortex-A53 phones work; newer phones are simply faster)
- About 2 GB of RAM for Lite, about 3.5 GB for Standard
- ABI: `arm64-v8a` only. x86 emulators are not supported
- The download only runs while the app is open (the screen stays awake during it)
- The context window is 4096 tokens; older turns are trimmed automatically

## Project layout

```
app/src/main/cpp/            CMake + JNI bridge to llama.cpp
app/src/main/java/.../engine/    LlamaEngine, ModelProvisioner, PromptBuilder, UTF-8 stream decoder
app/src/main/java/.../markdown/  Markdown parser + syntax highlighter (pure Kotlin, unit tested)
app/src/main/java/.../tts/       SpeechController, speech text cleaning
app/src/main/java/.../ui/        Chat, Settings, theme, Markdown renderer
```

## License

Source: Apache License 2.0 (see `LICENSE`). Model weights use their own license; review the upstream Qwen license before redistributing.

[kingxtech.name.ng](https://kingxtech.name.ng) · [github.com/KingzAlkhasim](https://github.com/KingzAlkhasim)
